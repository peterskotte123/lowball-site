// Background service worker: all API calls go through here. Extension-origin fetches with host_permissions are
// exempt from CORS preflights and from Chrome's Local Network Access permission, which blocks content-script fetches
// from public sites to loopback (the local dev API) and would otherwise need a per-site grant.
// Only the extension's own scripts may ask for a POST, and only to Lowball's API (or the local dev API when the build carries that permission).
// Which browser this is, so the server can attribute data by browser rather than guessing from install ids.
// The extension URL scheme is the one signal that cannot be spoofed by a polyfill: moz-extension:// on Gecko,
// chrome-extension:// on Chromium. Sent on the existing client header rather than adding a new one, because that
// header is already in the CORS allowlist.
var CLIENT = (function () {
  try {
    var v = chrome.runtime.getManifest().version;
    var u = chrome.runtime.getURL('');
    return v + ' ' + (u.indexOf('moz-extension') === 0 ? 'firefox' : u.indexOf('safari-web-extension') === 0 ? 'safari' : 'chrome');
  } catch (e) { return '0'; }
})();

var OK_URL = /^(https:\/\/api\.lowball\.rent|http:\/\/127\.0\.0\.1:8787)\/v1\/(score|score_batch|estimate|flag|observe|outcome|renewal)$/;
chrome.runtime.onMessage.addListener(function (m, sender, send) {
  if (m && m.type === 'lowball:open' && sender && sender.id === chrome.runtime.id && typeof m.url === 'string' && /^https:\/\/www\.zillow\.com\//.test(m.url)) { chrome.tabs.create({ url: m.url, active: true }); send({ ok: true }); return; }
  if (!m || m.type !== 'lowball:post') return;
  if (!sender || sender.id !== chrome.runtime.id || typeof m.url !== 'string' || !OK_URL.test(m.url)) { send({ ok: false, status: 0, error: 'blocked' }); return; }
  var ac = new AbortController(); var t = setTimeout(function () { ac.abort(); }, 10000);
  fetch(m.url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Lowball-Client': CLIENT },
                 body: JSON.stringify(m.body), signal: ac.signal })
    .then(function (r) { return r.text().then(function (txt) { send({ ok: r.ok, status: r.status, text: txt, retryAfter: r.headers.get('Retry-After') }); }); })
    .catch(function (e) { send({ ok: false, status: 0, error: e.name + ': ' + e.message }); })
    .finally(function () { clearTimeout(t); });
  return true;
});

chrome.runtime.onInstalled.addListener(function (d) {
  if (d && d.reason === 'install') chrome.tabs.create({ url: chrome.runtime.getURL('welcome.html') });
});
