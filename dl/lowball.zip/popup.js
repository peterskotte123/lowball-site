(function () {
  var cb = document.getElementById('share');
  chrome.storage.local.get(['lb_consent'], function (v) { cb.checked = v && v.lb_consent === true; });
  cb.addEventListener('change', function () { chrome.storage.local.set({ lb_consent: cb.checked, lb_consent_v: 3 }); });
})();