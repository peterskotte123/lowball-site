(function () {
  var tg = document.getElementById('tg'), st = document.getElementById('state');
  function show(on) { tg.classList.toggle('on', on === true); st.textContent = on === true ? 'On. The fields below are sent as you browse.' : 'Off. Nothing below is sent.'; }
  var ask = document.getElementById('ask');
  chrome.storage.local.get(['lb_consent'], function (v) { show(v && v.lb_consent === true); if (v && (v.lb_consent === true || v.lb_consent === false)) ask.hidden = true; });   // the question shows until it has been answered
  document.getElementById('yes').addEventListener('click', function () { chrome.storage.local.set({ lb_consent: true, lb_consent_v: 3 }); show(true); ask.hidden = true; chrome.tabs.create({ url: 'https://www.zillow.com/homes/for_rent/' }); });
  document.getElementById('no').addEventListener('click', function () { ask.hidden = true; chrome.tabs.create({ url: 'https://www.zillow.com/homes/for_rent/' }); });   // leaves the choice open: the panel asks once at the first estimate
  tg.addEventListener('click', function () { var on = !tg.classList.contains('on'); chrome.storage.local.set({ lb_consent: on, lb_consent_v: 3 }); show(on); });
  chrome.storage.onChanged.addListener(function (ch, area) { if (area === 'local' && ch.lb_consent) show(ch.lb_consent.newValue === true); });
})();
