(function () {
  'use strict';
  if (window.top !== window) return;                                   // one instance per tab
  if (!(typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id)) return;   // orphaned after an extension reload
  // Production API. A local server is only tried from the development harness (localhost), never from zillow.com.
  // Developer mode: on the local harness, or when localStorage.lowball_dev = '1' is set in the page console.
  var HAS_LOOPBACK = (function () { try { return (chrome.runtime.getManifest().host_permissions || []).some(function (h) { return h.indexOf('127.0.0.1') >= 0; }); } catch (e) { return false; } })();
  // Store builds carry no loopback permission, so the page-writable localStorage flag is inert there.
  var DEV = location.hostname === 'localhost' || (HAS_LOOPBACK && (function () { try { return localStorage.getItem('lowball_dev') === '1'; } catch (e) { return false; } })());
  var API_HOSTS = DEV ? ['http://127.0.0.1:8787/v1'] : ['https://api.lowball.rent/v1'];
  var API = API_HOSTS[0] + '/score';
  var CLIENT_VERSION = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getManifest) ? chrome.runtime.getManifest().version : '0';
  function apiFallback() { if (API_HOSTS[1] && API.indexOf(API_HOSTS[1]) < 0) { API = API_HOSTS[1] + '/score'; log('switching to ' + API_HOSTS[1]); return true; } return false; }
  // POST via the background worker (see bg.js), one retry on network failure (not on 4xx/5xx).
  function post(url, body, signal) {
    var once = function () {
      return new Promise(function (res, rej) {
        if (!(chrome.runtime && chrome.runtime.id)) return rej(new Error('Extension context invalidated'));
        chrome.runtime.sendMessage({ type: 'lowball:post', url: url, body: body }, function (r) {
          if (chrome.runtime.lastError || !r) return rej(new Error(chrome.runtime.lastError ? chrome.runtime.lastError.message : 'no response'));
          if (r.status === 0) return rej(new TypeError(r.error || 'Failed to fetch'));
          res({ ok: r.ok, status: r.status, text: function () { return Promise.resolve(r.text); }, json: function () { return Promise.resolve(JSON.parse(r.text)); } });
        });
      });
    };
    return once().catch(function (e) {
      if ((signal && signal.aborted) || /invalidated/.test(e.message)) throw e;
      return new Promise(function (res) { setTimeout(res, 2500); }).then(once);
    });
  }
  window.__lowballPost = post;

  var scoredZpid = null;      // zpid whose result is currently rendered
  var lastResult = null;      // { zpid, listing, r }
  var panelClosed = false;    // user closed the panel for scoredZpid
  var seq = 0;                // request token: only the newest in-flight request may render
  var inflight = null;        // AbortController for the newest request
  var seen = {};              // zpid -> compact listing captured from Zillow's own responses
  var seenOrder = [];

  // ---- Consented data sharing: one snapshot per listing per day, no personal data. Off until the user says yes. ----
  var prefs = { consent: null, id: null, sent: {} };
  var store = (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) ? chrome.storage.local : null;
  try { chrome.storage.onChanged.addListener(function (ch, area) { if (area === 'local' && ch.lb_consent) prefs.consent = ch.lb_consent.newValue === true ? true : (ch.lb_consent.newValue === false ? false : null); }); } catch (e) {}
  function loadPrefs(cb) {
    if (!store) { cb(); return; }
    store.get(['lb_consent', 'lb_consent_v', 'lb_id', 'lb_sent'], function (v) {
      prefs.consent = (v.lb_consent === true) ? true : (v.lb_consent === false ? false : null);
      if (prefs.consent === true && v.lb_consent_v !== POLICY_V) { prefs.consent = null; store.set({ lb_consent: null }); log('privacy policy changed; asking for sharing consent again'); }   // consent given under an older policy is asked again
      prefs.id = v.lb_id || null; prefs.sent = v.lb_sent || {};
      var today = new Date().toISOString().slice(0, 10);
      Object.keys(prefs.sent).forEach(function (k) { if (prefs.sent[k] !== today) delete prefs.sent[k]; });
      if (!prefs.id) { prefs.id = Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2); store.set({ lb_id: prefs.id }); }
      cb();
    });
  }
  var POLICY_V = 3;   // bump when the privacy policy changes what sharing sends; existing consent is asked again
  function setConsent(v) { prefs.consent = v; if (store) store.set({ lb_consent: v, lb_consent_v: POLICY_V }); log('data sharing', v ? 'on' : 'off'); }
  function observe(kind, key, data) {
    if (prefs.consent !== true || !key) return;
    var today = new Date().toISOString().slice(0, 10); var k = kind + ':' + key;
    if (prefs.sent[k] === today) return;
    prefs.sent[k] = today; if (store) store.set({ lb_sent: prefs.sent });
    post(API.replace('/score', '/observe'), { install: prefs.id, kind: kind, key: String(key), data: data }).catch(function () {});
  }
  // Shared listing snapshot (consent only). Same fields as the weekly scrape's rows (addr, zip, lat, lon, price, beds, baths,
  // sqft, type, days, tax) plus what only a listing page carries: year built, history, lease term, fees, flags. Never the
  // description, the Zestimate, or anything about the person browsing.
  function listingSnapshot(l) {
    var p = l._raw || {}, rf = p.resoFacts || {};
    return { zpid: l.zpid, addr: l.address, address: l.address, city: l.city, zip: l.zip, lat: l.lat, lon: l.lon, price: l.price, base_rent: l.base_rent, beds: l.beds, baths: l.baths,
             sqft: l.sqft, year: l.year, type: l.type, days: l.days, tax: typeof rf.taxAssessedValue === 'number' ? rf.taxAssessedValue : (typeof p.taxAssessedValue === 'number' ? p.taxAssessedValue : null),
             lease_term: rf.leaseTerm || null, laundry: Array.isArray(rf.laundryFeatures) ? rf.laundryFeatures.slice(0, 4) : null, parking: Array.isArray(rf.parkingFeatures) ? rf.parkingFeatures.slice(0, 4) : null,
             garage: rf.hasGarage === true ? true : (rf.hasGarage === false ? false : null), ac: rf.hasCooling === true ? true : (rf.hasCooling === false ? false : null), photos: typeof p.photoCount === 'number' ? p.photoCount : null,
             special_offers: l.special_offers, listed_by_owner: l.listed_by_owner,
             is_complex: l.is_complex, unit_count: l.unit_count, lease_months: l.lease_months, corporate_feed: l.corporate_feed,
             short_term: l.short_term, furnished: l.furnished, building_name: l.building_name, building_key: l.building_key, contacts: l.contacts,
             price_history: (l.price_history || []).slice(0, 12) };
  }
  // Search-result cards (consent only): the same rows the weekly scrape produces, from the pages the user already loads.
  var cardsSent = {};
  function observeCards(list, seq, kind) {
    kind = kind || 'cards';
    if (prefs.consent !== true) return;
    var day = new Date().toISOString().slice(0, 10), rows = [];
    list.forEach(function (c) {
      var k = String(c.zpid) + ':' + (c.price || c.minPrice || '') + ':' + day; if (cardsSent[k]) return; cardsSent[k] = true;
      rows.push({ zpid: c.zpid, addr: c.addr || c.address || null, city: c.city || null, zip: c.zip || null, lat: c.lat, lon: c.lon, price: c.price, priceChange: c.priceChange, changedDate: c.changedDate,
                  beds: c.beds, baths: c.baths, sqft: c.sqft, type: c.type || null, year: c.year, days: c.days, isBuilding: !!c.isBuilding, name: c.name || null, detailUrl: c.detailUrl || null, avail: c.avail, units: c.units || null });
    });
    for (var i = 0; i < rows.length; i += 30) {
      post(API.replace('/score', '/observe'), { install: prefs.id, kind: kind, key: kind + ':' + day + ':' + (seq || 0) + ':' + i, data: { url: location.pathname, cards: rows.slice(i, i + 30) } }).catch(function () {});
    }
    if (rows.length) log('shared', rows.length, kind === 'map' ? 'map pins' : 'search cards');
  }

  function log() { console.log.apply(console, ['[Lowball]'].concat([].slice.call(arguments))); }
  function money(v) { return '$' + Math.round(v).toLocaleString('en-US'); }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function urlZpid() { var m = location.pathname.match(/(\d+)_zpid/); return m ? Number(m[1]) : null; }

  // Which listing is on screen? URL first; otherwise a listing link inside Zillow's open modal/dialog.
  function currentZpid() {
    // Building pages score from the unit list on the page. A unit dialog there may link to the unit's own zpid, but
    // we never have full listing data for it, so treating it as an open listing would freeze the panel.
    if (isBuildingPage() && !urlZpid()) return null;
    var z = urlZpid(); if (z) return z;
    var boxes = document.querySelectorAll('dialog[open], [role="dialog"], [aria-modal="true"]');
    for (var i = boxes.length - 1; i >= 0; i--) {
      var box = boxes[i];
      if (!(box.offsetWidth || box.offsetHeight || box.getClientRects().length)) continue;
      var a = box.querySelector('a[href*="_zpid"], link[href*="_zpid"]');
      var m = a && (a.getAttribute('href') || '').match(/(\d+)_zpid/);
      if (m) return Number(m[1]);
      var d = box.querySelector('[data-zpid]');
      if (d && /^\d+$/.test(d.getAttribute('data-zpid'))) return Number(d.getAttribute('data-zpid'));
    }
    return null;  // no canonical fallback: it lags behind modal open/close
  }

  // ---- Building pages (/apartments/..., /b/...): no zpid, several units. Read the unit list off the page. ----
  function isBuildingPage() { return /^\/(apartments|b)\//.test(location.pathname); }
  // Zillow's default landing is for-sale. Lowball stays silent there: the pill, the ranking, and follow-ups only on rental pages.
  function isRentalContext() {
    if (isBuildingPage()) return true;
    if (/for_rent|\/rentals\/?|\/apartments\//i.test(location.pathname + location.search)) return true;
    if (/"isForRent"|%22fr%22|"fr":\{"value":true/i.test(decodeURIComponent(location.search))) return true;
    return false;
  }
  var buildingKey = null, buildingBusy = false;

  // Building pages embed their unit list in page data. Walk it for arrays of unit-like objects.
  function unitsFromPageData() {
    var s = document.getElementById('__NEXT_DATA__'); if (!s) return [];
    var nd; try { nd = JSON.parse(s.textContent); } catch (e) { return []; }
    var found = [];
    function pick(o, keys) { for (var i = 0; i < keys.length; i++) if (o[keys[i]] != null && o[keys[i]] !== '') return o[keys[i]]; return null; }
    function num(v) { if (v == null) return null; var n = Number(String(v).replace(/[^0-9.]/g, '')); return isFinite(n) && n > 0 ? n : null; }
    function isUnit(o) { return o && typeof o === 'object' && !Array.isArray(o) && pick(o, ['beds', 'bedrooms']) != null && (pick(o, ['price', 'minPrice', 'rent', 'listPrice', 'unformattedPrice']) != null || pick(o, ['sqft', 'livingArea', 'squareFeet', 'area']) != null); }
    // Other properties embedded in the page (nearby homes, similar rentals, search cards) carry an address or
    // coordinates; a unit of this building never does. Only arrays under a unit-list key count.
    function isOther(o) { return !!(o.latLong || o.address || o.streetAddress || o.homeType || o.homeStatus || o.detailUrl || o.hdpUrl); }
    var KEY = /^(floorPlans|units|ungroupedUnits|availableUnits|unitsWithPrice|unitList)$/;
    function walk(o, depth, under) {
      if (!o || depth > 14) return;
      if (typeof o === 'string') { if (o.length > 500 && o.charAt(0) === '{' && o.indexOf('bed') >= 0) { try { walk(JSON.parse(o), depth + 1, under); } catch (e) {} } return; }
      if (typeof o !== 'object') return;
      if (Array.isArray(o)) {
        if (under && o.length && o.length < 400 && o.every(isUnit) && !o.some(isOther) && o.length > found.length) found = o;
        o.forEach(function (v) { walk(v, depth + 1, under); }); return;
      }
      Object.keys(o).forEach(function (k) { walk(o[k], depth + 1, under || KEY.test(k)); });
    }
    walk(nd.props || nd, 0, false);
    var units = found.map(function (o) {
      var beds = num(pick(o, ['beds', 'bedrooms'])); if (beds == null && /studio/i.test(String(pick(o, ['beds', 'bedrooms']) || ''))) beds = 0;
      var price = num(pick(o, ['price', 'minPrice', 'rent', 'listPrice', 'unformattedPrice']));
      return { unit: (pick(o, ['unitNumber', 'unitName', 'name', 'unit', 'title']) || '').toString().replace(/^unit\s*/i, '').slice(0, 30) || null,
               beds: beds == null ? 0 : beds, baths: num(pick(o, ['baths', 'bathrooms'])), price: price, por: !price,
               sqft: num(pick(o, ['sqft', 'livingArea', 'squareFeet', 'area'])), fromData: true };
    }).filter(function (u) { return u.beds != null && (u.unit || u.sqft) && (u.price == null || (u.price >= 400 && u.price <= 30000)); });
    if (units.length) log('units from page data:', units.length);
    return units;
  }

  // Text of the unit-detail pane that is on screen: the container around a visible "N beds, N baths | $price" header.
  function openedPaneText() {
    var hdr = /^\s*\d\s*beds?,\s*\d(?:\.\d)?\s*baths?\s*\|/i, hint = /\d\s*beds?,/i;
    var best = null, bestD = Infinity, vh = window.innerHeight || 800;
    var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT), node;
    while ((node = walker.nextNode())) {
      if (!hint.test(node.data)) continue;
      var el = node.parentElement, ok = false;
      for (var i = 0; i < 3 && el && el !== document.body; i++, el = el.parentElement) { var t = el.textContent || ''; if (t.length > 80) break; if (hdr.test(t)) { ok = true; break; } }
      if (!ok || el.closest('#lowball-panel') || el.closest('[aria-hidden="true"]')) continue;
      var r = el.getBoundingClientRect(); if (!r.width || !r.height) continue;
      if (r.right + window.scrollX <= 0 || r.left >= document.documentElement.scrollWidth) continue;   // parked beside the page: a previous building's pane
      var d = r.bottom < 0 ? -r.bottom : r.top > vh ? r.top - vh : 0;   // distance from the viewport; 0 when on screen
      if (d < bestD) { bestD = d; best = el; }
    }
    if (!best || bestD > vh * 2) return '';
    var box = best; for (var j = 0; j < 8 && box.parentElement && box.parentElement !== document.body && (box.innerText || '').length < 600; j++) box = box.parentElement;
    return box.innerText || '';
  }

  function unitsFromTables() {
    // Zillow's building page renders available units as table rows (data-test-id="unit-table-row"). The first cell
    // stacks the unit name, "1 bd, 1 ba" and a "Floor plan" button; the size column is a bare number ("730").
    var out = [];
    document.querySelectorAll('table').forEach(function (tb) {
      if (tb.closest('#lowball-panel') || tb.closest('[aria-hidden="true"]')) return;
      var r = tb.getBoundingClientRect();
      if (!r.width || !r.height || r.right + window.scrollX <= 0 || r.bottom + window.scrollY <= 0) return;   // hidden or parked off the page: a leftover from a previous building
      var heads = Array.prototype.map.call(tb.querySelectorAll('th'), function (th) { return (th.innerText || '').trim().toLowerCase(); });
      var sqCol = -1; heads.forEach(function (h, i) { if (sqCol < 0 && /sq|size|area/.test(h)) sqCol = i; });
      tb.querySelectorAll('tr').forEach(function (tr) {
        var tds = Array.prototype.filter.call(tr.querySelectorAll('td'), function (td) { return (td.innerText || '').trim(); });
        var cells = tds.map(function (td) { return (td.innerText || '').replace(/\s+/g, ' ').trim(); });
        if (cells.length < 2) return;
        var row = cells.join(' | ');
        var pm = row.match(/\$([\d,]+)/); var bm = row.match(/(\d)\s*(?:bd|beds?|br)\b/i) || (/\bstudio\b/i.test(row) ? [null, '0'] : null);
        if (!pm && !/price on request|contact/i.test(row)) return;
        if (!bm) return;
        var price = pm ? Number(pm[1].replace(/,/g, '')) : null;
        if (pm && (price < 400 || price > 30000)) return;
        var bam = row.match(/(\d(?:\.\d)?)\s*(?:ba|baths?)\b/i);
        var sm = row.match(/(\d{1,2},?\d{3}|\d{3})\s*(?:sq\.?\s?ft\.?|sqft|square feet)/i), sqft = sm ? Number(sm[1].replace(/,/g, '')) : null;
        if (!sqft) {
          // the Sqft column holds a bare number; without a header, a lone 3-4 digit cell that is not the price
          var sqCell = sqCol >= 0 && heads.length === tds.length ? cells[sqCol] : null;
          if (sqCell == null) sqCell = cells.filter(function (c) { return /^\d{1,2},?\d{3}$|^\d{3}$/.test(c); })[0] || null;
          if (sqCell && /^\d{1,2},?\d{3}$|^\d{3}$/.test(sqCell)) { var sq = Number(sqCell.replace(/,/g, '')); if (sq >= 150 && sq <= 9999) sqft = sq; }
        }
        // the unit name is the first line of the first cell; a first line that is itself a bed count or price is a summary row
        var first = ((tds[0].innerText || '').split('\n').map(function (x) { return x.trim(); }).filter(Boolean)[0] || '');
        var name = /^\$|^(?:\d\s*(?:bd|bed|br)|studio)\b|^\d(?:\.\d)?\s*ba|^\d[\d,]*\s*sq/i.test(first) ? null : first;
        // A row with neither a unit name nor a size is a summary row: a floor-plan "from" price ("1 bed | $2,995+")
        // or a Rental Market Summary median ("1 bed | $2,796"). Neither is a unit of this building.
        if (!name && !sqft) return;
        out.push({ unit: name ? name.replace(/^unit\s*/i, '').slice(0, 30) : null, beds: Number(bm[1]), baths: bam ? Number(bam[1]) : null, price: price, por: !price, sqft: sqft, fromTable: true });
      });
    });
    if (out.length !== tableLogged) { tableLogged = out.length; if (out.length) log('units from table rows:', out.length); }
    return out;
  }
  var tableLogged = 0;

  function parseBuilding() {
    var full = document.body.innerText || '';
    // In-page navigation leaves the previous building's panes in the document after this one's content. This
    // building's text runs from its name to the first "Contact property" / "Listed by" after its unit list.
    var h1t = ((document.querySelector('h1') || {}).innerText || '').trim(), h1i = h1t ? full.indexOf(h1t) : -1;
    var auI = full.search(/Available units/i), ownEnd = -1;
    if (auI >= 0) { var tail0 = full.slice(auI + 20); var e0 = tail0.search(/Contact property|Listed by management|Listed by property/i); if (e0 >= 0) ownEnd = auI + 20 + e0; }
    if (ownEnd > 0) full = full.slice(Math.max(0, h1i), ownEnd);
    // Only the "Available units" section describes this building's units. Rental Market Summary lists area medians.
    // "Available units" also appears in Zillow's tab bar. Try every occurrence and keep the longest section
    // that ends at the next section marker; the tab-bar one is a few words long.
    var END = /Rental Market Summary|Rent Zestimate|Facts, features|Neighborhood:|Contact property/i;
    var text = '', re0 = /Available units/gi, mm;
    while ((mm = re0.exec(full))) {
      var tail = full.slice(mm.index); var zRel = tail.search(END);
      var seg = zRel > 0 ? tail.slice(0, zRel) : tail.replace(/Rental Market Summary[\s\S]*$/i, '');
      if (seg.length > text.length) text = seg;
    }
    if (!text) text = full.replace(/Rental Market Summary[\s\S]*$/i, '');
    var paneText = openedPaneText();
    var textAll = full + '\n' + paneText;   // this building's own text plus the unit pane on screen (rendered after it)
    var units = [], re = /(?:(?:Unit|Floorplan|Floor plan)\s+([\w-]+(?: [\w-]+)?)\s+)?(\d)\s*beds?,\s*(\d(?:\.\d)?)\s*baths?\s*\|\s*(\$[\d,]+|Price on request|Contact for price)(?:[\s\S]{0,400}?(\d{1,2},?\d{3}|\d{3})\s*sqft)?/gi, m;
    while ((m = re.exec(text)) && units.length < 40) {
      var por = !/^\$/.test(m[4]);
      var price = por ? null : Number(m[4].replace(/[$,]/g, ''));
      if (!por && (price < 400 || price > 30000)) continue;
      units.push({ unit: m[1] || null, beds: Number(m[2]), baths: Number(m[3]), price: price, por: por, sqft: m[5] ? Number(m[5].replace(/,/g, '')) : null });
    }
    // The opened unit's detail pane is a dialog rendered at the end of the document, after the section markers.
    // Zillow also leaves panes from previously viewed buildings in the document, off screen, so read the header form
    // "Unit X / N beds, N baths | $price" only from the pane that is actually visible; fall back to the whole page.
    var paneHit = false, paneSrc = false;
    function scanOpened(src) { re.lastIndex = 0; paneSrc = src === paneText && !!paneText; while ((m = re.exec(src)) && units.length < 40) {
      if (!(m[1] || m[5])) continue;
      paneHit = true;
      var por2 = !/^\$/.test(m[4]), price2 = por2 ? null : Number(m[4].replace(/[$,]/g, ''));
      if (!por2 && (price2 < 400 || price2 > 30000)) continue;
      var name2 = m[1] || null, sq2 = m[5] ? Number(m[5].replace(/,/g, '')) : null;
      var dup = units.some(function (u) { return (name2 && u.unit && u.unit.toLowerCase() === name2.toLowerCase()) || (u.price === price2 && u.beds === Number(m[2]) && u.baths === Number(m[3]) && (u.sqft === sq2 || !u.sqft)); });
      if (dup) { units.forEach(function (u) { if ((name2 && u.unit && u.unit.toLowerCase() === name2.toLowerCase()) || (u.price === price2 && u.beds === Number(m[2]) && u.baths === Number(m[3]))) { if (!u.sqft && sq2) u.sqft = sq2; if (!u.unit && name2) u.unit = name2; } }); continue; }
      units.push({ unit: name2, beds: Number(m[2]), baths: Number(m[3]), price: price2, por: por2, sqft: sq2, fromPane: paneSrc });
    } }
    // the pane box can stop short of the unit's name and size (deeply nested header); then read the whole page
    scanOpened(paneText || full); if (paneText && !paneHit) { scanOpened(document.body.innerText || ''); if (paneHit) textAll = document.body.innerText || ''; }
    // a "Floorplan X" heading may precede the beds line: pick it up as the unit name when none was captured
    if (units.length && !units[0].unit) { var fp = text.match(/Floor ?plan:?\s*([^\n]{2,40})/i); if (fp) units[0].unit = fp[1].trim(); }
    var tableUnits = unitsFromTables();
    if (tableUnits.length >= units.filter(function (u) { return !u.group; }).length) {
      // table rows are the real list; carry over the opened unit's detail (sqft) and mark it
      tableUnits.forEach(function (tu) {
        var m = units.filter(function (u) { return !u.group && ((u.unit && tu.unit && u.unit.toLowerCase() === tu.unit.toLowerCase()) || (u.price === tu.price && u.beds === tu.beds)); })[0];
        if (m) { if (m.sqft && !tu.sqft) tu.sqft = m.sqft; if (m.unit && !tu.unit) tu.unit = m.unit; if (m.baths != null && tu.baths == null) tu.baths = m.baths; tu.isOpened = !m.fromTable && !m.group && (m.unit || m.sqft) ? true : false; }
      });
      // an opened unit the table does not list (its row is collapsed, or its price differs from the group's "from" price) stays,
      // but only from the pane on screen: text units found elsewhere on the page are another building's leftovers
      var lost = units.filter(function (u) { return !u.group && !u.fromTable && !u.fromData && u.fromPane && (u.unit || u.sqft) && !tableUnits.some(function (tu) { return tu.isOpened; }); });
      units = tableUnits.concat(lost);
    }
    var hasTable = tableUnits.length > 0;
    var seenU = {}; units = units.filter(function (u) { var k = [u.unit, u.beds, u.baths, u.price].join('|'); if (seenU[k]) return false; seenU[k] = true; return true; });
    // Floor-plan summary rows: "2 bed $4,000+" / "Studio $2,300+". Add bed types the detailed list didn't cover.
    var reG = /(?:^|\n)\s*(Studio|(\d)\s*beds?)\s*\n?\s*\$([\d,]+)\+[ ]*(?=[\n\t]|$)/gi, g, groups = [];
    while ((g = reG.exec(text))) {
      var gb = /studio/i.test(g[1]) ? 0 : Number(g[2]); var gp = Number(g[3].replace(/,/g, ''));
      if (gp < 400 || gp > 30000) continue;
      if (!groups.some(function (x) { return x.beds === gb; })) groups.push({ unit: null, beds: gb, baths: null, price: gp, sqft: null, group: true });
    }
    var realUnits = units.filter(function (u) { return !u.group && !u.fromData && (u.unit || u.sqft || u.fromTable); });
    var availN = (textAll.match(/(?:^|\n)[^\n]*?\b(\d{1,3})[ \t]+(?:available units?|units? available)\b/i) || textAll.match(/Your matches \((\d{1,3})\)/i) || [])[1]; availN = availN ? Number(availN) : null;
    groups.forEach(function (gr) {
      if (hasTable) return;   // the table is the building's inventory; plan rows are its "from" prices, not extra units
      if (units.some(function (u) { return u.beds === gr.beds; })) return;
      // a plan row for a size the page lists no real unit of, when the page says all available units are already accounted for, is marketing, not inventory
      if (realUnits.length && availN != null && availN <= realUnits.length) return;
      units.push(gr);
    });
    units.forEach(function (u) { if (u.unit) u.unit = String(u.unit).replace(/^unit\s*/i, '').replace(/(?:Close|Back)$/i, '').trim(); });   // a dialog's Close button can abut the unit name
    // A unit is "opened" only when its detail block is on screen: the text form "N beds, N baths | $price" with a name or sqft.
    var openedText = units.filter(function (u) { return !u.group && !u.fromTable && !u.fromData && (u.unit || u.sqft); });
    openedText.forEach(function (u) { u.isOpened = true; });
    var opened = openedText.slice();
    var dataUnits = unitsFromPageData();
    if (dataUnits.length && groups.length) {
      // the page's floor-plan summary lists every bed type on offer; page-data units of other types are not this building's
      var okBeds = {}; groups.forEach(function (g2) { okBeds[g2.beds] = true; }); units.forEach(function (u) { if (!u.group) okBeds[u.beds] = true; });
      var kept = dataUnits.filter(function (d) { return okBeds[d.beds]; });
      if (kept.length !== dataUnits.length) { log('page data units rejected:', dataUnits.length - kept.length, 'bed type not on this page'); dataUnits = kept; }
    }
    if (dataUnits.length) {
      // page data is the source of truth for the list; keep sqft consistent between summary and opened views
      dataUnits.forEach(function (d) {
        var m = units.filter(function (u) { return !u.group && ((u.unit && d.unit && u.unit.toLowerCase() === d.unit.toLowerCase()) || (u.price && d.price && u.price === d.price && u.beds === d.beds)); })[0];
        if (m) { if (!m.sqft && d.sqft) m.sqft = d.sqft; if (m.baths == null && d.baths != null) m.baths = d.baths; m.isOpened = m.isOpened || openedText.indexOf(m) >= 0; d.opened = m; }
      });
      var merged = dataUnits.map(function (d) { return d.opened || d; });
      openedText.forEach(function (o) { if (merged.indexOf(o) < 0) { o.isOpened = true; merged.push(o); } });
      units = merged;
    }
    var openedUnit = units.filter(function (u) { return u.isOpened; })[0] || (units.length === 1 && !units[0].group && (units[0].unit || units[0].sqft) && !units[0].fromTable ? units[0] : null);
    var lease = (textAll.match(/Lease length:\s*(\d+)\s*months?/i) || textAll.match(/Based on a (\d+)-month lease/i) || [])[1];
    var openedUnitRef = units.filter(function (u) { return u.isOpened; })[0];
    if (openedUnitRef && openedUnitRef.por) {
      var sim = textAll.match(/Similar units[\s\S]{0,120}?same floor ?plan[\s\S]{0,400}?\$([\d,]+)\s+(\d{3,5})?/i);
      if (sim) { openedUnitRef.price = Number(sim[1].replace(/,/g, '')); openedUnitRef.por = false; openedUnitRef.priceFromSibling = true; if (!openedUnitRef.sqft && sim[2]) openedUnitRef.sqft = Number(sim[2]); }
    }
    var zip = (textAll.match(/\b[A-Z]{2}\s+(\d{5})\b/) || [])[1] || null;
    var name = (document.querySelector('h1') || {}).textContent || document.title.split('|')[0];
    // Exact costs from the opened unit's cost calculator (never estimated when the listing states them).
    var costSrc = paneText || textAll;
    function cost(re2) { var mm2 = costSrc.match(re2); return mm2 ? Number(mm2[1].replace(/,/g, '')) : null; }
    var costs = { base: cost(/Monthly base rent\s*\$([\d,]+)/), total_monthly: cost(/Est\. total monthly cost\s*\$([\d,]+)/), deposit: cost(/Security deposit(?:\s*Security deposit disclaimer)?\s*\$([\d,]+)/i),
                  application: cost(/Est\. total application cost\s*\$([\d,]+)/) || cost(/Application fee\s*\$([\d,]+)/i), move_in: cost(/Est\. move-in cost\s*\$([\d,]+)/), holding: cost(/Holding deposit\s*\$([\d,]+)/i) };
    var base = costs.base ? String(costs.base) : null;
    var special = (textAll.match(/[^.\n]*(weeks? free|months? free|rest of \w+ free|\$[\d,]+ off|free rent|move-in special|look and lease)[^.\n]*/i) || [])[0] || null;
    var avail = availN;   // same line only: the ZIP above the heading must not become the count
    return { name: (name || '').trim().slice(0, 80), zip: zip, units: units, opened: openedUnit, lease_months: lease ? Number(lease) : null, base_rent: base ? Number(base.replace(/,/g, '')) : null,
             special: special ? special.trim().slice(0, 140) : null, available: Math.max(avail ? Number(avail) : 0, units.length), costs: costs };
  }

  function scoreBuilding() {
    if (buildingBusy) return;
    var b = parseBuilding();
    var key = location.pathname + '|' + b.units.map(function (u) { return u.unit + u.price; }).join(',') + '|open:' + (b.opened ? (b.opened.unit || '') + b.opened.price + (b.opened.sqft || '') : '');
    if (!b.units.length) { if (buildingKey !== 'none') { log('building page: no units parsed yet'); buildingKey = 'none'; renderWaiting(); } return; }
    if (key === buildingKey) return;
    buildingKey = key; buildingBusy = true;
    log('building page:', b.name, b.units.length, 'units, special:', b.special);
    var reqs = b.units.map(function (u) {
      var body = { price: u.price, beds: u.beds, baths: u.baths, sqft: u.sqft, zip: b.zip, type: 'APARTMENT', days: 0,
                   is_complex: true, unit_count: b.available, special_offers: b.special ? [b.special] : [],
                   base_rent: (b.base_rent && b.base_rent < u.price && !u.group && (b.opened === u || b.units.length === 1)) ? b.base_rent : null };
      if (u.por) delete body.price;
      if (b.opened === u && b.lease_months) body.lease_months = b.lease_months;
      return post(u.por ? API.replace('/score', '/estimate') : API, body)
        .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); }).then(function (r) { r.por = !!u.por; return r; });
    });
    Promise.all(reqs).then(function (results) {
      buildingBusy = false;
      if (!isBuildingPage()) return;
      if (results.some(function (r) { return !r || r.error || (r.fair == null && r.offer == null); })) throw new Error('HTTP 422 (unscorable unit)');
      try { renderBuilding(b, results); } catch (e) { log('render error', e && e.stack); throw e; }
      observe('building', location.pathname, { name: b.name, zip: b.zip, units: b.units, special: b.special, available: b.available, lease_months: b.lease_months });
    }).catch(function (e) { buildingBusy = false; if (!/^HTTP/.test(e.message) && apiFallback()) { buildingKey = null; scoreBuilding(); return; } log('building score error', e.message); setTimeout(function () { buildingKey = null; }, 15000);
      renderError(null, /invalidated/.test(e.message) ? 'Lowball was updated. Reload this page.' : 'Lowball is temporarily unavailable. Retrying shortly.'); });
  }

  function propertyFromNextData(text) {
    var nd; try { nd = JSON.parse(text); } catch (e) { return null; }
    var cache = nd && nd.props && nd.props.pageProps && nd.props.pageProps.componentProps && nd.props.pageProps.componentProps.gdpClientCache;
    if (!cache) return null;
    var g; try { g = typeof cache === 'string' ? JSON.parse(cache) : cache; } catch (e) { return null; }
    var p = null;
    Object.keys(g).forEach(function (k) { if (!p && g[k] && g[k].property && Array.isArray(g[k].property.priceHistory)) p = g[k].property; });
    return p;
  }

  // Words that only a short-stay listing uses. "guests", "stay" and "reservation" alone flagged ordinary homes ("space for family, guests").
  var SHORT_TERM_RE = /short[- ]term|month[- ]to[- ]month|30[- ]day|seasonal|corporate housing|vacation rental|weekly rate|nightly|per night|sublet|sublease|temporary housing|extended stay|per week|flexible lease|\bmonth\(s\)|\d+[- ]month(?:s)? stay|minimum stay|\d+[- ]night|guests? (?:welcome|allowed|per night)|check[- ]in (?:time|after|at)|co-host|damage protection|airbnb|vrbo/i;
  var FURNISHED_RE = /furnish|turnkey|turn-key|king[- ]size bed|queen[- ]size bed|linens|beach paraphernalia|all utilities included|fully equipped|move-in ready with everything/i;
  function factsFurnished(p) {
    var rf = p.resoFacts || {}; var v = rf.furnished != null ? rf.furnished : p.furnished;
    if (v === true || /^(yes|true|furnished)$/i.test(String(v || ''))) return true;
    if (/^(no|false|unfurnished)$/i.test(String(v || ''))) return false;
    return null;   // unknown: fall back to the description
  }
  function pageContacts() {   // "202 days on Zillow | 15 contacts" in the listing header
    var m = (document.body.innerText || '').match(/(\d{1,5})\s+contacts?\b(?![\s\S]{0,3}(?:manager|property|agent|us))/); var n = m ? Number(m[1]) : null; return n != null && n <= 5000 ? n : null;   // the header count only, never an ID before "Contact manager"
  }

  function toListing(p) {
    var l0 = toListing0(p); if (l0) Object.defineProperty(l0, '_raw', { value: p, enumerable: false });   // snapshot facts only; never serialized to the API
    return l0;
  }
  function toListing0(p) {
    if (!p) return null;
    if (p.homeStatus !== 'FOR_RENT') { log('not a rental listing, status =', p.homeStatus); return null; }
    var unitCount = p.building && p.building.rentalUnitsSummary && p.building.rentalUnitsSummary.unitCount;
    var buildingName = p.building && p.building.buildingName;
    var feeIncl = p.listPriceIncludesRequiredMonthlyFees === true && typeof p.baseRent === 'number' && p.baseRent < p.price;
    var rf = p.resoFacts || {};
    var sqft = p.livingArea || p.livingAreaValue || rf.livingArea || rf.aboveGradeFinishedArea || null;
    if (typeof sqft === 'string') sqft = Number(sqft.replace(/[^0-9.]/g, '')) || null;
    var fees = p.rentalCostsAndFees || {};
    return {
      zpid: Number(p.zpid), price: p.price, base_rent: feeIncl ? p.baseRent : null,
      beds: p.bedrooms, baths: p.bathrooms, sqft: sqft, year: p.yearBuilt,

      lat: p.isUndisclosedAddress ? null : p.latitude, lon: p.isUndisclosedAddress ? null : p.longitude,
      zip: p.zipcode, type: p.homeType, days: p.daysOnZillow, zillow_shown: p.rentZestimate,
      price_history: (p.priceHistory || []).filter(function (h) { return h && /^\d{4}-\d{2}-\d{2}/.test(String(h.date || '')); }).slice(0, 30).map(function (h) { return { date: String(h.date).slice(0, 10), price: fnum(h.price), event: h.event, rental: h.postingIsRental === true }; }),
      special_offers: p.specialOffers || [], listed_by_owner: !!p.isListedByOwner,
      // unitCount is units listed right now, not building size. A named building with a non-owner poster is a managed complex.
      is_complex: !!((unitCount && unitCount >= 5) || (buildingName && !p.isListedByOwner && p.homeType === 'APARTMENT')),
      unit_count: unitCount || null,
      short_term: SHORT_TERM_RE.test(p.description || ''),
      furnished: factsFurnished(p) === null ? FURNISHED_RE.test(p.description || '') : factsFurnished(p),
      contacts: pageContacts(),
      building_name: buildingName || null,
      building_key: (p.building && p.building.bdpUrl && (p.building.bdpUrl.match(/-([A-Za-z0-9]{6})\/?$/) || [])[1]) || null,
      lease_months: typeof fees.leaseDuration === 'number' ? fees.leaseDuration : null,
      corporate_feed: /#\s*Id\d+p\b/i.test(p.streetAddress || ''),
      address: (p.streetAddress || '').slice(0, 200), city: (p.city || '').slice(0, 60)
    };
  }

  function remember(p) {
    var listing = toListing(p);
    if (!listing) return null;
    var z = listing.zpid;
    if (!seen[z]) { seenOrder.push(z); if (seenOrder.length > 50) delete seen[seenOrder.shift()]; }
    seen[z] = listing;
    return listing;
  }

  function uiOpts() {
    return { onClose: function () { panelClosed = true; }, pageUrl: location.href.split('?')[0], api: API,
             installId: prefs.consent === true ? prefs.id : null, onResetId: function () { prefs.id = Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2); prefs.sent = {}; if (store) store.set({ lb_id: prefs.id, lb_sent: {} }); return prefs.id; },
             consent: prefs.consent, onConsent: setConsent,
             onCounter: function (amount, listing, r) {   // a landlord's counter is an outcome worth keeping, joined to the quote it answers
               post(API.replace('/score', '/outcome'), { install: prefs.consent === true ? prefs.id : null, quote_id: r.quote_id || null, kind: 'countered', amount: amount, letter: 'offer', zip: listing.zip || null, beds: listing.beds, asking: r.asking, offer: r.offer, settle: r.settle, days_since: 0 }).catch(function () {});
             },
             onEvent: function (name, key, listing, r) {
               observe('event', name + ':' + key + ':' + Date.now(), { name: name, key: key, url: location.pathname });
               if (/^copy_/.test(name) && listing && r) rememberFollowup({ id: (r.quote_id || '') + ':' + key, quote_id: r.quote_id || null, key: String(key), address: listing.address || '', zip: listing.zip || null, beds: listing.beds, asking: r.asking, offer: r.offer, settle: r.settle, kind: name, letter: name.replace('copy_', ''), at: Date.now(), done: false, snooze: 0 });
             } };
  }
  // ---- Follow-ups: a week after a letter is copied, ask what happened. Local only until answered; answers go to /outcome without the address.
  var FOLLOWUP_AFTER = DEV ? 0 : 5 * 86400000;
  var followups = [], followupShown = null;
  function loadFollowups(cb) { if (!store) return cb(); store.get(['lb_followups'], function (v) { followups = (v && v.lb_followups) || []; cb(); }); }
  function saveFollowups() { if (store) store.set({ lb_followups: followups.slice(-40) }); }
  function rememberFollowup(f) {
    loadFollowups(function () {
      if (followups.some(function (x) { return x.key === f.key && !x.done; })) return;
      followups.push(f); saveFollowups(); log('follow-up scheduled for', f.address);
    });
  }
  function dueFollowup() { var now = Date.now(); return followups.filter(function (f) { return !f.done && now - f.at >= FOLLOWUP_AFTER && now >= (f.snooze || 0); })[0] || null; }
  function showFollowup(f) {
    followupShown = f.id;
    LowballUI.followup(f, Object.assign(uiOpts(), {
      onAnswer: function (kind, amount) {
        f.done = true; f.answer = kind; saveFollowups();
        post(API.replace('/score', '/outcome'), { install: prefs.consent === true ? prefs.id : null, quote_id: f.quote_id, kind: kind, amount: amount, letter: f.letter, zip: f.zip, beds: f.beds, asking: f.asking, offer: f.offer, settle: f.settle, days_since: Math.round((Date.now() - f.at) / 86400000) }).catch(function (e) { log('outcome post failed', e.message); });
      },
      onLater: function () { f.snooze = Date.now() + 3 * 86400000; saveFollowups(); followupShown = null; },
      onDone: function () { followupShown = null; }
    }));
  }

  var buildingShown = false;
  function renderBuilding(b, results) {
    buildingShown = true;
    var pi = b.opened ? b.units.indexOf(b.opened) : -1;
    if (pi < 0 && b.units.length > 1) {
      // No unit opened: a range from the lowest-priced unit's estimate to the highest-priced one's.
      var priced = b.units.map(function (u, i) { return { u: u, r: results[i] }; }).filter(function (x) { return x.u.price; }).sort(function (a, c2) { return a.u.price - c2.u.price; });
      if (priced.length >= 2) {
        var lo = priced[0], hi = priced[priced.length - 1];
        var o2 = uiOpts(); o2.buildingName = b.name; o2.available = b.available;
        var groups = {}; var order = [];
        b.units.forEach(function (u, i) {
          var k = [u.beds, u.baths, u.sqft, u.price, u.por].join('|'); if (!groups[k]) { groups[k] = { u: u, r: results[i], names: [], n: 0 }; order.push(k); }
          groups[k].n++; if (u.unit) groups[k].names.push(u.unit);
        });
        o2.rows = order.map(function (k) { var g = groups[k], u = g.u, r = g.r;
          var bed = u.beds === 0 ? 'Studio' : u.beds + ' bed'; var size = u.sqft ? ' · ' + u.sqft + ' sf' : '';
          var label = g.n > 1 ? bed + size + ' · ' + g.n + ' units' + (g.names.length ? ' (' + g.names.slice(0, 3).join(', ') + ')' : '') : (u.unit ? 'Unit ' + u.unit + ' · ' + bed + size : bed + size);
          return { label: label, plan: g.n > 1 ? 'the ' + bed + ' units' + (u.sqft ? ' (' + u.sqft + ' sq ft)' : '') : (u.unit ? 'Unit ' + u.unit : 'the ' + bed), count: g.n, asking: u.por ? null : u.price, open: u.por ? r.fair : r.offer, settle: u.por ? r.range_high : r.settle, comps: r.comps_median };
        });
        LowballUI.range(b, { lo: lo, hi: hi }, o2);
        return;
      }
    }
    if (pi < 0) pi = 0;
    var others = b.units.map(function (u, i) { return { u: u, r: results[i] }; }).filter(function (x, i) { return i !== pi; }).map(function (x) {
      return { beds: x.u.beds, label: (x.u.group ? (x.u.beds === 0 ? 'Studio' : x.u.beds + ' bed') + ' from' : (x.u.unit ? 'Unit ' + x.u.unit : x.u.beds + 'bd/' + x.u.baths + 'ba')), asking: x.u.por ? null : x.u.price, open: x.u.por ? x.r.fair : x.r.offer, settle: x.u.por ? x.r.range_high : x.r.settle, comps: x.r.comps_median };
    });
    {
      var u = b.units[pi], r = results[pi];
      var o = uiOpts(); o.others = others; o.available = b.available; o.buildingName = b.name; if (!u.group && (b.opened === u || b.units.length === 1)) o.costs = b.costs; o.planLabel = u.group ? (u.beds === 0 ? 'Studio' : u.beds + ' bed') : (u.unit ? 'Unit ' + u.unit : u.beds + ' bed');
      if (u.por) { LowballUI.estimate({ address: b.name + (u.unit ? ' · ' + u.unit : ''), beds: u.beds, baths: u.baths, sqft: u.sqft }, r, o); return; }
      if (u.priceFromSibling) r.signals = ['No price posted for this unit. Using ' + '$' + u.price.toLocaleString() + ', the rent of an identical floor plan listed in this building.'].concat(r.signals || []);
      if (b.special && !(r.signals || []).some(function (s) { return /special/i.test(s) && s.indexOf(b.special) >= 0; })) r.signals = ['Posted special: ' + b.special].concat(r.signals || []);
      LowballUI.score({ address: b.name + (u.unit ? ' · Unit ' + u.unit : u.group ? ' · ' + (u.beds === 0 ? 'Studio' : u.beds + ' bed') : ''), city: '', beds: u.beds, baths: u.baths, sqft: u.sqft, days: 0, zpid: 0 }, r, o);
    }
  }
  var hintSeen = null;
  function render(listing, r) {
    if (listing.zpid && r && r.offer != null) cardScore[Number(listing.zpid)] = { zpid: listing.zpid, asking: r.asking, offer: r.offer, settle: r.settle, fair: r.fair, over_pct: r.over_pct, confidence: r.confidence, beyond: r.beyond, national: r.national, refined: true };   // the ranking row now matches the panel
    if (listing.zpid && cardScore[Number(listing.zpid)]) { try { findCards().forEach(function (c) { if (cardZpid(c) === Number(listing.zpid)) paintBadge(c, cardScore[Number(listing.zpid)]); }); } catch (e) {} }
    var o = uiOpts();
    if (hintSeen === false) { o.firstHint = true; hintSeen = true; if (store) store.set({ lb_hint_seen: 1 }); }
    LowballUI.score(listing, r, o);
  }
  if (store) store.get(['lb_hint_seen'], function (v) { hintSeen = !!(v && v.lb_hint_seen); }); else hintSeen = true;
  function renderError(listing, msg) { LowballUI.error(listing, msg, Object.assign(uiOpts(), { onRetry: function () { scoredZpid = null; buildingKey = null; failedAt = {}; if (isBuildingPage()) scoreBuilding(); else scoreCurrent(); } })); }
  function renderWaiting() { if (!isRentalContext() || urlZpid()) return; LowballUI.waiting({ onClose: function () { waitingHidden = true; } }); }
  var waitingHidden = false;

  function clearPanel() {
    scoredZpid = null; lastResult = null; panelClosed = false;
    var cur = document.getElementById('lowball-panel'); if (cur && cur.getAttribute('data-state') === 'deals' && !currentZpid()) return;
    if (!waitingHidden) renderWaiting(); else { var p = document.getElementById('lowball-panel'); if (p && p.getAttribute('data-state') !== 'waiting') p.remove(); }
  }

  // When Zillow loads a listing in place, the page data block is stale. Re-read the page that is open in this tab
  // (only ever location.href, never a constructed URL) to get the listing's data. Disclosed in the privacy policy.
  var refetched = {};
  function refetchCurrentPage(want) {
    if (refetched[want]) return;
    refetched[want] = true;
    setTimeout(function () {
      if (seen[want] || currentZpid() !== want) return;
      log('re-reading the open page for zpid', want);
      fetch(location.href, { credentials: 'same-origin' }).then(function (r) { return r.text(); }).then(function (html) {
        var m = html.match(/<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/);
        var p = m ? propertyFromNextData(m[1]) : null;
        log('page re-read got zpid', p && p.zpid, m ? '' : '(no page data in response)');
        if (p && Number(p.zpid) === want) { remember(p); scoreCurrent(); }
      }).catch(function (e) { log('page re-read failed', e.message); });
    }, 1200);
  }

  var failedAt = {}, inflightZpid = null;
  function scoreCurrent() {
    var want = currentZpid();
    if (!want) { if (scoredZpid !== null || !document.getElementById('lowball-panel')) { log('no listing open'); clearPanel(); } return; }
    if (want === scoredZpid) return;
    if (failedAt[want] && Date.now() - failedAt[want] < 60000) return;     // a failed score is not retried every poll; Retry clears this
    if (inflightZpid === want) return;
    var listing = seen[want];
    if (!listing) {
      var s = document.getElementById('__NEXT_DATA__');
      var p = s ? propertyFromNextData(s.textContent) : null;
      if (p && Number(p.zpid) === want) listing = remember(p);
    }
    if (!listing) { log('no full listing data yet for zpid', want, '(waiting for Zillow to load it)'); refetchCurrentPage(want); return; }

    var my = ++seq; inflightZpid = want;
    if (inflight) inflight.abort();
    inflight = new AbortController();
    log('scoring', listing.address, listing.price, 'zpid', want);
    var payload = Object.assign({}, listing); delete payload.zillow_shown; delete payload.building_key; delete payload.building_name;
    post(API, payload, inflight.signal)
      .then(function (res) { if (!res.ok) throw new Error('HTTP ' + res.status); return res.json(); })
      .then(function (r) {
        if (inflightZpid === want) inflightZpid = null;
        if (my !== seq || currentZpid() !== want) { log('stale result for', want, 'dropped'); return; }
        scoredZpid = want; lastResult = { zpid: want, listing: listing, r: r }; panelClosed = false; waitingHidden = false;
        log('score: open', r.offer, 'settle', r.settle, r.leverage, 'for', want);
        render(listing, r);
        observe('listing', want, listingSnapshot(listing));
      })
      .catch(function (e) {
        if (inflightZpid === want) inflightZpid = null;
        if (e.name === 'AbortError' || my !== seq || currentZpid() !== want) return;
        if (!/^HTTP/.test(e.message) && apiFallback()) { scoredZpid = null; scoreCurrent(); return; }
        log('API error', e.message);
        scoredZpid = null; failedAt[want] = Date.now();
        renderError(listing, /invalidated/.test(e.message) ? 'Lowball was updated. Reload this page.'
          : /^HTTP 4/.test(e.message) ? 'Lowball could not score this listing (' + e.message + ').'
          : 'Lowball is temporarily unavailable. It will retry when you open the next listing.');
      });
  }

  // Full listing objects captured by hook.js as Zillow loads them (covers in-place navigation and the search modal).
  document.addEventListener('lowball:property', function (ev) {
    var p; try { p = JSON.parse(ev.detail); } catch (e) { return; }
    if (!p || !p.zpid) return;
    var listing = remember(p);
    if (listing && listing.zpid === currentZpid() && listing.zpid !== scoredZpid) { log('captured zpid', listing.zpid, 'from network'); scoreCurrent(); }
  });

  // URL watcher (Zillow is a single-page app) and panel watchdog.
  var healthTimer = null, healthFlagged = {};
  function armHealth(z) {
    clearTimeout(healthTimer);
    healthTimer = setTimeout(function () {
      if (!z || currentZpid() !== z || scoredZpid === z || seen[z] || healthFlagged[z]) return;
      if (document.getElementById('lowball-panel') && document.getElementById('lowball-panel').getAttribute('data-state') === 'error') return;
      var s = document.getElementById('__NEXT_DATA__'); var p = s ? propertyFromNextData(s.textContent) : null;
      if (p && p.homeStatus && p.homeStatus !== 'FOR_RENT') return;                 // a for-sale page: stay silent
      healthFlagged[z] = true;
      renderError(null, 'Lowball could not read this listing. If the page looks like a rental, the site layout may have changed; we have been notified.');
      post(API.replace('/score', '/flag'), { install: prefs.consent === true ? prefs.id : null, kind: 'flag', reason: 'parse_failed', note: 'no listing data within 12s', url: location.pathname, listing: {}, result: {} }).catch(function () {});
    }, 12000);
  }
  var lastUrl = location.href;
  setInterval(function () {
    if (location.href !== lastUrl) {
      var wasSearch = /rentals|for_rent|apartments/i.test(lastUrl) && !/_zpid/.test(lastUrl);
      lastUrl = location.href; buildingKey = null; dealsKey = ''; dealsDismissed = '';
      if (!(wasSearch && isRentalContext() && !urlZpid())) pageCards = [];   // same search, new bounds or filters: keep the list until its payload lands
      if (buildingShown && !isBuildingPage()) { buildingShown = false; var bp = document.getElementById('lowball-panel'); if (bp) bp.remove(); waitingHidden = false; }
      setTimeout(scoreCurrent, 300); return;
    }
    if (isBuildingPage() && !currentZpid()) { scoreBuilding(); return; }
    var z = currentZpid(); var panel = document.getElementById('lowball-panel');
    if (!z) {
      if (scoredZpid !== null || (!panel && !waitingHidden)) clearPanel();
      var due = isRentalContext() ? dueFollowup() : null; var st = panel && panel.getAttribute('data-state');
      if (due && !followupShown && st !== 'followup') showFollowup(due);
      else if (!due && (st === 'waiting' || st === 'deals' || !panel) && Object.keys(cardScore).length >= 3) renderDeals();
      return;
    }
    if (z !== scoredZpid) { scoreCurrent(); if (!seen[z]) armHealth(z); return; }
    if (lastResult && lastResult.zpid === z && !panel && !panelClosed) { render(lastResult.listing, lastResult.r); return; }
    if (panel) LowballUI.moveIntoTopDialog();
  }, 500);

  // ---- Search-result card badges ----
  var cardData = {};      // zpid -> compact listing from Zillow's search payload
  var cardScore = {};     // zpid -> score result
  var cardPending = {};   // zpid -> true while queued
  var badgeTimer = null;
  var pageCards = [];   // zpids in the latest results payload for this search; filters and map moves replace it, scrolling does not
  var cardsSeq = 0;   // request order of the payload on screen; an older search's response arriving late is dropped
  document.addEventListener('lowball:cards', function (ev) {
    var msg; try { msg = JSON.parse(ev.detail); } catch (e) { return; }
    var list = Array.isArray(msg) ? msg : (msg && msg.cards) || [], seq = Array.isArray(msg) ? 0 : Number(msg.seq) || 0;
    if (msg && msg.map) { log('map pins in payload:', list.length); try { observeCards(list, seq, 'map'); } catch (e) {} return; }   // shared for coverage; the ranking stays on this page's list
    if (seq && seq < cardsSeq) { log('search payload', seq, 'is older than', cardsSeq, '- dropped'); return; }
    if (seq) cardsSeq = seq;
    var n = 0, nb = 0; var ids = [];
    list.forEach(function (cd) {
      if (cd.isBuilding) {
        // a building card lists each floor plan's "from" price; score each as a unit of the building (its key is a string, never a zpid)
        (cd.units || []).forEach(function (u) {
          var price = Number(String(u.price == null ? '' : u.price).replace(/[^0-9.]/g, '')), beds = fnum(u.beds);   // "$2,400+"
          if (!price || price < 400 || price > 30000 || beds == null || beds > 9) return;
          var key = 'b:' + cd.zpid + ':' + beds;
          cardData[key] = { key: key, plan: true, isBuilding: true, price: price, beds: beds, baths: null, sqft: null, lat: cd.lat, lon: cd.lon, zip: cd.zip, type: 'APARTMENT', days: 0,
                            name: cd.name || cd.address || 'Building', detailUrl: cd.detailUrl || null, avail: cd.avail, address: cd.address };
          ids.push(key); nb++;
        });
        return;
      }
      cardData[Number(cd.zpid)] = cd; ids.push(Number(cd.zpid)); n++;
    });
    if (ids.length) { pageCards = ids; dealsKey = ''; }
    log('cards from search payload:', n, 'listings,', nb, 'building floor plans'); scheduleBadges();
    try { observeCards(list, seq); } catch (e) {}
  });
  function cardZpid(card) {
    var a = card.querySelector('a[href*="_zpid"]'); var m = a && (a.getAttribute('href') || '').match(/(\d+)_zpid/);
    return m ? Number(m[1]) : null;
  }
  function cardFromDom(card, zpid) {
    var txt = (card.innerText || '').replace(/\s+/g, ' ');
    var pm = txt.match(/\$([\d,]+)(\+)?\s*\/?\s*mo/i) || txt.match(/\$([\d,]+)(\+)?/);
    var price = pm ? Number(pm[1].replace(/,/g, '')) : null; if (!price || price < 400 || price > 30000) return null;
    var bm = txt.match(/(\d+)\s*bds?\b/i) || txt.match(/(\d+)\s*beds?\b/i); var bam = txt.match(/(\d+(?:\.\d)?)\s*ba\b/i); var sm = txt.match(/([\d,]+)\s*sqft/i);
    var zm = txt.match(/\b[A-Z]{2}\s+(\d{5})\b/);
    return { zpid: zpid, price: price, beds: bm ? Number(bm[1]) : (/studio/i.test(txt) ? 0 : null), baths: bam ? Number(bam[1]) : null, sqft: sm ? Number(sm[1].replace(/,/g, '')) : null, zip: zm ? zm[1] : null, isBuilding: !!pm[2] };
  }
  function findCards() {
    var sel = ['article[data-test="property-card"]', '[data-test="property-card"]', 'article', 'li[class*="ListItem"]'];
    for (var i = 0; i < sel.length; i++) { var els = Array.prototype.filter.call(document.querySelectorAll(sel[i]), function (el) { return cardZpid(el) && /\$/.test(el.innerText || ''); }); if (els.length) return els; }
    return [];
  }
  // Debounced 600ms after the last DOM change, but never later than 2s after the first request: Zillow's map tiles,
  // pins and ad carousels mutate the document continuously, and a pure debounce would starve the pass.
  var badgeDue = 0;
  function scheduleBadges() { clearTimeout(badgeTimer); if (!badgeDue) badgeDue = Date.now() + 2000; badgeTimer = setTimeout(applyBadges, Math.min(600, Math.max(0, badgeDue - Date.now()))); }
  function applyBadges() {
    badgeDue = 0;
    if (urlZpid() && !document.querySelector('[data-test="property-card"], article')) return;
    // Score every listing in the search payload, not only the cards rendered: a virtualized list renders a few, the
    // map-only layout none. The cards on screen get badges; the ranking reads from the payload.
    var cards = findCards(), domById = {};
    cards.forEach(function (card) { var z = cardZpid(card); if (z) domById[z] = card; });
    var ids = Object.keys(domById).map(Number); pageCards.forEach(function (z) { if (!domById[z]) ids.push(z); });
    if (!ids.length) return;
    var need = [];
    ids.forEach(function (z) {
      var card = domById[z];
      if (cardScore[z]) { if (card) paintBadge(card, cardScore[z]); return; }
      if (cardPending[z]) return;
      var cd = cardData[z] || (card && cardFromDom(card, z)); if (!cd || !cd.price || (cd.isBuilding && !cd.plan)) return;
      if (!cd.zip && !cd.lat && card) { var d = cardFromDom(card, z); if (d && d.zip) cd.zip = d.zip; }
      if (cd.plan) {
        cardPending[z] = true;
        need.push({ key: z, price: cd.price, beds: cd.beds, baths: null, sqft: null, lat: fnum(cd.lat), lon: fnum(cd.lon), zip: cd.zip ? String(cd.zip).slice(0, 5) : null, type: 'APARTMENT', days: 0, is_complex: true, unit_count: fnum(cd.avail) || null });
        return;
      }
      try {
        var price = fnum(cd.price); if (!price || price <= 0) return;
        var hist = [], chg = fnum(cd.priceChange), days = Math.max(0, Math.round(fnum(cd.days) || 0));
        if (chg && chg < 0) {
          var when = isoDay(cd.changedDate) || isoDay(Date.now());
          var listedOn = isoDay(Date.now() - days * 86400000);
          hist = [{ date: when, price: price, event: 'Price change', rental: true }, { date: listedOn < when ? listedOn : when, price: price - chg, event: 'Listed for rent', rental: true }];
        }
        cardPending[z] = true;
        need.push({ zpid: z, price: price, beds: fnum(cd.beds), baths: fnum(cd.baths), sqft: fnum(cd.sqft), year: fnum(cd.year), lat: fnum(cd.lat), lon: fnum(cd.lon), zip: cd.zip ? String(cd.zip).slice(0, 5) : null, type: typeof cd.type === 'string' ? cd.type : 'APARTMENT', days: days, price_history: hist });
      } catch (e) { log('card skipped', z, e.message); }
    });
    if (!need.length) { renderDeals(); return; }
    for (var i = 0; i < need.length && i < 200; i += 40) sendBatch(need.slice(i, i + 40), 0);   // the API takes 40 a batch; a page of buildings has more floor plans than that
  }
  function fnum(v) { if (v == null || v === '') return null; var n = typeof v === 'number' ? v : Number(String(v).replace(/[$,]/g, '')); return isFinite(n) ? n : null; }
  function isoDay(v) { try { var d = new Date(v); return isNaN(d.getTime()) ? null : d.toISOString().slice(0, 10); } catch (e) { return null; } }
  function sendBatch(items, attempt) {
    log('scoring', items.length, 'cards');
    var keys = items.map(function (n) { return n.key || n.zpid; });
    var wire = items.map(function (n) { var w = {}; Object.keys(n).forEach(function (k) { if (k !== 'key') w[k] = n[k]; }); return w; });   // the key is ours, not the API's
    var done = function () { keys.forEach(function (k) { delete cardPending[k]; }); };
    post(API.replace('/score', '/score_batch'), { items: wire })
      .then(function (r) { return r.text().then(function (t) { return { ok: r.ok, status: r.status, text: t }; }); })
      .then(function (r) {
        var body = {}; try { body = JSON.parse(r.text); } catch (e) {}
        if (!r.ok) {
          done();
          if (r.status === 422 && attempt === 0 && Array.isArray(body.detail)) {
            // drop the rejected items and resend the rest once
            var bad = {}; body.detail.forEach(function (d) { var loc = d.loc || []; if (loc[1] === 'items' && typeof loc[2] === 'number') bad[loc[2]] = true; });
            var rest = items.filter(function (_, i) { return !bad[i]; });
            log('batch 422:', JSON.stringify(body.detail).slice(0, 300), '· dropped', items.length - rest.length);
            if (rest.length) { rest.forEach(function (n) { cardPending[n.key || n.zpid] = true; }); sendBatch(rest, 1); }
            return;
          }
          log('batch error', r.status, r.text.slice(0, 200)); return;
        }
        (body.results || []).forEach(function (r2, i) { if (!r2 || r2.error) return; var k = keys[i] != null && String(keys[i]).charAt(0) === 'b' ? keys[i] : Number(r2.zpid); if (k) cardScore[k] = r2; });   // results come back in request order; building plans have no zpid
        done();
        findCards().forEach(function (card) { var z = cardZpid(card); if (z && cardScore[z]) paintBadge(card, cardScore[z]); });
        renderDeals();
      }).catch(function (e) { done(); if (apiFallback()) scheduleBadges(); else log('badge error', e.message); });
  }
  // Open a ranked listing the way Zillow does: its card's own click handler shows the overlay on this search page. The
  // card's anchor carries target=_blank on desktop, so clicking the anchor is what spawned new tabs. Order: card-level
  // click on the price, then the anchor with target removed, then a new tab via the background page (window.open after an
  // async wait is popup-blocked). Ctrl/Cmd/middle click always means a new tab.
  function openListing(match, href, ev, onTab) {
    if (ev && (ev.ctrlKey || ev.metaKey || ev.button === 1)) { newTab(href, onTab); return; }
    var card = null; Array.prototype.forEach.call(document.querySelectorAll('article, [data-test="property-card"], li[class*="ListItem"]'), function (c) { if (!card && !c.closest('#lowball-panel') && match.card(c)) card = c; });   // building cards carry no _zpid link, so search every card here
    var a = card && (card.querySelector('a[data-test="property-card-link"]') || card.querySelector('a[href*="_zpid"], a[href*="/apartments/"], a[href*="/b/"]'));
    if (!card) { newTab(href, onTab); return; }
    card.scrollIntoView({ block: 'center' });
    var target = card.querySelector('[data-test="property-card-price"]') || card.querySelector('address') || card;
    target.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
    opened(match, 900, function (ok) {
      if (ok) return;
      if (a) { var tb = a.getAttribute('target'); a.removeAttribute('target'); a.click(); if (tb) a.setAttribute('target', tb); }
      opened(match, 900, function (ok2) { if (!ok2) newTab(href, onTab); });
    });
  }
  function opened(match, ms, cb) { var t0 = Date.now(); var id = setInterval(function () { var hit = match.here(); if (hit || Date.now() - t0 > ms) { clearInterval(id); cb(!!hit); } }, 60); }
  function newTab(href, onTab) { if (!href) { log('no link to open'); return; } log('opening in a new tab', href); try { chrome.runtime.sendMessage({ type: 'lowball:open', url: href }, function (r) { if (!r || !r.ok) { log('background open failed', chrome.runtime.lastError && chrome.runtime.lastError.message); window.open(href, '_blank', 'noopener'); } }); } catch (e) { window.open(href, '_blank', 'noopener'); } if (onTab) onTab(); }
  function homeMatch(z) { return { card: function (c) { return cardZpid(c) === z; }, here: function () { return new RegExp('\\b' + z + '_zpid').test(location.pathname) || !!document.querySelector('[role="dialog"] a[href*="' + z + '_zpid"], dialog[open] a[href*="' + z + '_zpid"]'); } }; }
  function buildingMatch(detailUrl) { var d = (detailUrl || '').replace(/"/g, ''); return { card: function (c) { return !!(d && c.querySelector('a[href*="' + d + '"]')); }, here: function () { return !!(d && (location.pathname.indexOf(d) >= 0 || document.querySelector('[role="dialog"] a[href*="' + d + '"], dialog[open] a[href*="' + d + '"]'))); } }; }
  var dealsKey = '', dealsDismissed = '';
  function renderDeals() {
    if (currentZpid() || isBuildingPage() || !isRentalContext()) return;   // only on rental search lists, never over an open listing
    if (dueFollowup && dueFollowup()) return;                             // a follow-up question takes the slot first
    var items = [], domById = {};
    findCards().forEach(function (card) { var z = cardZpid(card); if (z) domById[z] = card; });
    var universe = pageCards.length ? pageCards : Object.keys(domById).map(Number);
    if (universe.some(function (z) { return cardPending[z]; })) return;   // a batch is in flight: draw once, from the full set
    universe.forEach(function (z) {
      var r = cardScore[z]; if (!r) return;
      var cd0 = cardData[z];
      if (cd0 && cd0.plan) {
        var bhref = cd0.detailUrl ? 'https://www.zillow.com' + cd0.detailUrl : null;
        items.push({ zpid: z, building: true, newTab: !(cd0.detailUrl && document.querySelector('a[href*="' + cd0.detailUrl.replace(/"/g, '') + '"]')), open: function (ev, onTab) { openListing(buildingMatch(cd0.detailUrl), bhref, ev, onTab); }, label: (cd0.name + ' · ' + (cd0.beds ? cd0.beds + ' bed' : 'studio') + ' from').slice(0, 44), asking: r.asking != null ? r.asking : cd0.price, offer: r.offer, over: r.over_pct || 0, beyond: !!r.beyond, refined: false, href: bhref });
        return;
      }
      var card = domById[z]; var cd = cardData[z] || (card && cardFromDom(card, z));
      var asking = r.asking != null ? r.asking : (cd && fnum(cd.price)); if (!asking) return;
      var addr = (card && (card.querySelector('address') || {}).textContent) || (cd && cd.address) || (cd && cd.zip ? 'ZIP ' + cd.zip : 'zpid ' + z);
      var a = card && card.querySelector('a[href*="_zpid"]');
      items.push({ zpid: z, newTab: !card, open: function (ev, onTab) { openListing(homeMatch(z), a ? a.href : ('https://www.zillow.com/homedetails/' + z + '_zpid/'), ev, onTab); }, label: String(addr).replace(/\s+/g, ' ').replace(/,\s*[A-Z]{2}\s+\d{5}.*$/, '').trim().slice(0, 40), asking: asking, offer: r.offer, over: r.over_pct || 0, beyond: !!r.beyond, refined: !!r.refined, href: a ? a.href : ('https://www.zillow.com/homedetails/' + z + '_zpid/') });
    });
    var seen2 = {}; items = items.filter(function (it) { if (seen2[it.zpid]) return false; seen2[it.zpid] = true; return true; });
    if (items.length < 3) return;
    items.sort(function (a, b) { return (a.beyond - b.beyond) || (b.over - a.over); });   // listings beyond our data sort last: a +300% there is missing comps, not a bargain
    // Redraw only when the set of listings on the page changed (filters, scrolling, a new search); the throttle kept a stale list up after a filter change.
    var key = items.map(function (it) { return it.zpid + (it.refined ? 'r' : ''); }).sort().join(',');   // a row refined by the full listing redraws too
    var panel = document.getElementById('lowball-panel');
    if (key === dealsKey && panel && panel.getAttribute('data-state') === 'deals') return;
    dealsKey = key;
    if (dealsDismissed === key) return;
    var o = uiOpts(); o.roughIndex = items.some(function (it) { var r = cardScore[it.zpid]; return r && r.national; });
    o.onClose = function () { dealsDismissed = key; waitingHidden = true; };
    LowballUI.deals(items, o);
  }
  function paintBadge(card, r) {
    // A card badge is a first pass from the search card. Opening the listing scores it with the full details (year built,
    // full price history, contacts), and that result replaces the badge so the card and the panel say the same number.
    var stamp = String(r.offer) + (r.refined ? 'r' : 'c'), old = card.querySelector('.lowball-badge');
    if (old) { if (old.getAttribute('data-lb') === stamp) return; old.remove(); }
    var over = r.over_pct; var cls, text;
    if (r.beyond) { cls = 'hi'; text = 'Above all comps'; }
    else if (over >= 15) { cls = 'hi'; text = 'Over by ' + Math.round(over) + '%'; }
    else if (over >= 5) { cls = 'mid'; text = 'Over by ' + Math.round(over) + '%'; }
    else if (over <= -5) { cls = 'deal'; text = 'Under market'; }
    else { cls = 'ok'; text = 'At market'; }
    var b = document.createElement('span'); b.className = 'lowball-badge lb-' + cls; b.setAttribute('data-lb', stamp);
    b.textContent = (r.cut ? 'Cut ' + money(r.cut) + ' · ' : '') + text + ' · offer ' + (r.refined ? '' : '~') + money(r.offer);
    b.title = 'Lowball: fair rent about ' + money(r.fair) + ', likely to settle near ' + money(r.settle) + ' (confidence ' + r.confidence + ')' + (r.refined ? '' : '. First pass from the search card; opening the listing refines it.');
    var anchor = card.querySelector('[data-test="property-card-price"]') || card.querySelector('span[class*="price" i], div[class*="price" i]') || card.querySelector('a');
    if (anchor && anchor.parentNode) anchor.insertAdjacentElement('afterend', b); else card.appendChild(b);
  }
  new MutationObserver(function () { scheduleBadges(); }).observe(document.documentElement, { childList: true, subtree: true });

  try { document.documentElement.setAttribute('data-lowball', chrome.runtime.getManifest().version); } catch (e) {}
  log('loaded on', location.href, window.top === window ? '(top frame)' : '(iframe)', 'v' + (function () { try { return chrome.runtime.getManifest().version; } catch (e) { return '?'; } })());
  loadPrefs(function () { loadFollowups(function () {}); if (isBuildingPage()) scoreBuilding(); else scoreCurrent(); try { document.dispatchEvent(new CustomEvent('lowball:ready')); } catch (e) {} scheduleBadges(); });
})();
