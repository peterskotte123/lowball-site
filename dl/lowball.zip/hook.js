// Runs in the page's own JS context (world: MAIN). Watches Zillow's listing responses and hands
// each full listing object to the extension through a namespaced DOM event.
(function () {
  'use strict';
  if (window.top !== window) return;
  if (window.__lowballHooked) return;
  window.__lowballHooked = true;

  // Only the full listing object (the one with priceHistory) is trustworthy; search results and
  // "similar homes" lists carry lightweight objects with the same zpid but different price fields.
  function isFull(o) { return !!(o && o.zpid && o.homeStatus && Array.isArray(o.priceHistory) && typeof o.price === 'number'); }

  function findProperty(o, depth) {
    if (!o || depth > 5) return null;
    if (typeof o === 'string') {
      // Next.js data routes carry the listing inside gdpClientCache as a JSON string.
      if (o.length < 200 || o.indexOf('zpid') < 0 || o.charAt(0) !== '{') return null;
      try { return findProperty(JSON.parse(o), depth + 1); } catch (e) { return null; }
    }
    if (typeof o !== 'object') return null;
    if (isFull(o)) return o;
    if (isFull(o.property)) return o.property;
    var keys = Object.keys(o);
    for (var i = 0; i < keys.length && i < 80; i++) {
      var p = findProperty(o[keys[i]], depth + 1);
      if (p) return p;
    }
    return null;
  }

  function emit(p) {
    try { document.dispatchEvent(new CustomEvent('lowball:property', { detail: JSON.stringify(p) })); } catch (e) {}
  }

  function isCard(o) { return o && typeof o === 'object' && o.zpid && (o.latLong || (o.hdpData && o.hdpData.homeInfo)); }
  function findCards(o, depth) {
    if (!o || typeof o !== 'object' || depth > 8) return null;
    if (!Array.isArray(o) && Array.isArray(o.listResults) && o.listResults.length > 2 && o.listResults.slice(0, 3).every(isCard)) return o.listResults;   // the list, not the map pins
    if (Array.isArray(o)) { if (o.length > 2 && o.length < 1000 && o.slice(0, 3).every(isCard)) return o; for (var i = 0; i < o.length; i++) { var r = findCards(o[i], depth + 1); if (r) return r; } return null; }
    var keys = Object.keys(o);
    for (var j = 0; j < keys.length && j < 80; j++) { var r2 = findCards(o[keys[j]], depth + 1); if (r2) return r2; }
    return null;
  }
  var reqSeq = 0;   // request order; a search response that arrives after a newer request's response is stale
  function emitCards(cards, seq, map) {
    var slim = cards.map(function (c) {
      var hi = (c.hdpData && c.hdpData.homeInfo) || {};
      return { zpid: c.zpid, address: (c.address || hi.streetAddress || '').slice(0, 80), addr: (c.addressStreet || hi.streetAddress || '').slice(0, 80), city: (c.addressCity || hi.city || '').slice(0, 40), price: c.unformattedPrice || hi.price || null, beds: c.beds != null ? c.beds : hi.bedrooms, baths: c.baths != null ? c.baths : hi.bathrooms,
               sqft: c.area != null ? c.area : hi.livingArea, lat: (c.latLong && c.latLong.latitude) || hi.latitude, lon: (c.latLong && c.latLong.longitude) || hi.longitude,
               zip: c.addressZipcode || hi.zipcode, type: hi.homeType, days: hi.daysOnZillow, year: hi.yearBuilt != null ? hi.yearBuilt : null, isBuilding: !!c.isBuilding, minPrice: c.minBaseRent || null,
               priceChange: hi.priceChange != null ? hi.priceChange : (c.priceChange != null ? c.priceChange : null), changedDate: hi.datePriceChanged || c.changedDate || null,
               // apartment buildings: one "from" price per floor plan, the building's own page link, and how many units are open
               name: c.isBuilding ? String(c.buildingName || c.statusText || '').slice(0, 80) : null, detailUrl: c.isBuilding ? String(c.detailUrl || '').slice(0, 200) : null,
               avail: c.isBuilding ? (c.availabilityCount != null ? c.availabilityCount : null) : null,
               units: c.isBuilding && Array.isArray(c.units) ? c.units.slice(0, 8).map(function (u) { return { price: u.price, beds: u.beds }; }) : null };
    }).filter(function (c) { return c.zpid && (c.price || c.isBuilding); });
    try { document.dispatchEvent(new CustomEvent('lowball:cards', { detail: JSON.stringify({ seq: seq || 0, cards: slim, map: !!map }) })); } catch (e) {}
  }
  function findMap(o, depth) {   // the pins for the whole map view, when the response carries them
    if (!o || typeof o !== 'object' || depth > 8) return null;
    if (!Array.isArray(o) && Array.isArray(o.mapResults) && o.mapResults.length > 2 && o.mapResults.slice(0, 3).every(isCard)) return o.mapResults;
    if (Array.isArray(o)) { for (var i = 0; i < o.length && i < 50; i++) { var r = findMap(o[i], depth + 1); if (r) return r; } return null; }
    var keys = Object.keys(o);
    for (var j = 0; j < keys.length && j < 80; j++) { var r2 = findMap(o[keys[j]], depth + 1); if (r2) return r2; }
    return null;
  }
  function inspectText(text, seq) {
    if (!text || text.length < 200) return;
    if (text.indexOf('priceHistory') >= 0) { try { var p = findProperty(JSON.parse(text), 0); if (p) emit(p); } catch (e) {} return; }
    // search payloads: arrays of cards with zpid + latLong
    if (text.indexOf('latLong') >= 0 || text.indexOf('hdpData') >= 0) { try { var j = JSON.parse(text); var cards = findCards(j, 0); if (cards) emitCards(cards, seq); var pins = findMap(j, 0); if (pins && pins.length > (cards ? cards.length : 0)) emitCards(pins, seq, true); } catch (e) {} }
  }

  var XS = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function () {
    var seq = ++reqSeq;
    try { this.addEventListener('load', function () { try { if (this.responseType === '' || this.responseType === 'text') inspectText(this.responseText, seq); } catch (e) {} }); } catch (e) {}
    return XS.apply(this, arguments);
  };

  // The extension's listener starts after page load, so hold the first-load cards until it says it is ready.
  var pendingCards = null;
  function firstLoadCards() {
    var s = document.getElementById('__NEXT_DATA__'); if (!s) return;
    try { var cards = findCards(JSON.parse(s.textContent), 0); if (cards) { pendingCards = cards; emitCards(cards, 0); } } catch (e) {}
  }
  document.addEventListener('DOMContentLoaded', firstLoadCards);
  document.addEventListener('lowball:ready', function () { if (pendingCards) emitCards(pendingCards, 0); else firstLoadCards(); });

  var origFetch = window.fetch;
  window.fetch = function () {
    var call = origFetch.apply(this, arguments), seq = ++reqSeq;
    call.then(function (res) {
      try {
        var ct = res.headers.get('content-type') || '';
        if (/image|video|font|css|javascript|octet/i.test(ct)) return;
        var len = Number(res.headers.get('content-length') || 0); if (len > 5000000) return;
        res.clone().text().then(function (t) {
          inspectText(t, seq);
        }).catch(function () {});
      } catch (e) {}
    }).catch(function () {});
    return call;
  };
})();
