// Lowball panel UI. Renders into a shadow root so Zillow's CSS can't touch it and ours can't leak out.
// Loaded before content.js; exposes window.LowballUI.
(function () {
  'use strict';

  var CSS = [
    ':host { all: initial; }',
    '*, *::before, *::after { box-sizing: border-box; }',
    '.card { font: 14px/1.45 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Inter, Helvetica, Arial, sans-serif; color: #101828; background: #fff;',
    '  border-radius: 14px; border: 1px solid #E4E7EC; box-shadow: 0 1px 2px rgba(16,24,40,.06), 0 16px 40px -12px rgba(16,24,40,.28); overflow: hidden; width: 344px; }',
    '.card.waiting { width: auto; }',
    '.head { display: flex; align-items: center; gap: 8px; padding: 10px 10px 10px 12px; border-bottom: 1px solid #EAECF0; }',
    '.mark { width: 22px; height: 22px; border-radius: 6px; background: #101828; display: grid; place-items: center; flex: none; }',
    '.mark svg { width: 13px; height: 13px; }',
    '.wordmark { font-weight: 800; letter-spacing: -0.01em; font-size: 15px; white-space: nowrap; }',
    '.addr { color: #667085; font-size: 12px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex: 1; min-width: 0; }',
    '.btns { display: flex; gap: 2px; margin-left: auto; }',
    '.ib { width: 28px; height: 28px; border: 0; background: none; border-radius: 6px; color: #667085; cursor: pointer; display: grid; place-items: center; }',
    '.ib:hover { background: #F2F4F7; color: #101828; }',
    '.ib svg { width: 14px; height: 14px; }',
    '.body { padding: 14px 16px 12px; }',
    '.collapsed .body, .collapsed .actions, .collapsed .foot { display: none; }',
    '.label { font-size: 11px; font-weight: 600; letter-spacing: .08em; text-transform: uppercase; color: #667085; }',
    '.big { font-size: 40px; font-weight: 800; letter-spacing: -0.02em; line-height: 1.05; margin: 2px 0 4px; font-variant-numeric: tabular-nums; color: #101828; }',
    '.high .big { color: #157347; } .medium .big { color: #B45309; }',
    '.sub { color: #475467; font-size: 13px; }',
    '.land { margin-top: 10px; display: inline-flex; align-items: baseline; gap: 6px; background: #F8FAFC; border: 1px solid #EAECF0; border-radius: 8px; padding: 6px 10px; font-size: 13px; color: #475467; }',
    '.land b { color: #101828; font-size: 15px; font-variant-numeric: tabular-nums; }',
    '.stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin: 14px 0 12px; }',
    '.stat { background: #F8FAFC; border-radius: 8px; padding: 8px 10px; }',
    '.stat .label { font-size: 10px; }',
    '.stat .v { font-weight: 700; font-size: 15px; font-variant-numeric: tabular-nums; margin-top: 2px; }',
    '.meter { display: flex; align-items: center; gap: 10px; margin: 4px 0 10px; }',
    '.segs { display: flex; gap: 3px; flex: 1; }',
    '.seg { height: 6px; flex: 1; border-radius: 3px; background: #EAECF0; }',
    '.low .seg:nth-child(1) { background: #98A2B3; }',
    '.medium .seg:nth-child(-n+2) { background: #F59E0B; }',
    '.high .seg { background: #16A34A; }',
    '.meter .t { font-size: 12px; color: #475467; white-space: nowrap; }',
    '.meter .t b { color: #101828; text-transform: capitalize; }',
    '.why { list-style: none; margin: 0; padding: 0; display: grid; gap: 6px; }',
    '.why li { position: relative; padding-left: 16px; font-size: 13px; color: #344054; }',
    '.why li::before { content: ""; position: absolute; left: 3px; top: 8px; width: 5px; height: 5px; border-radius: 50%; background: #98A2B3; }',
    '.why li.warn::before { background: #F59E0B; }',
    'details { margin-top: 10px; font-size: 12px; }',
    'summary { cursor: pointer; color: #1D4ED8; font-weight: 600; list-style: none; }',
    'summary::-webkit-details-marker { display: none; }',
    'summary::before { content: "▸ "; } details[open] summary::before { content: "▾ "; }',
    'table { width: 100%; border-collapse: collapse; margin-top: 6px; }',
    'td, th { padding: 4px 3px; border-top: 1px solid #F2F4F7; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 150px; text-align: left; font-size: 12px; }',
    'table.units { table-layout: fixed; } table.units td:first-child, table.units th:first-child { white-space: normal; width: 44%; line-height: 1.25; }',
    'th { font-size: 10px; text-transform: uppercase; letter-spacing: .06em; color: #667085; border-top: 0; }',
    '.n { text-align: right; font-variant-numeric: tabular-nums; }',
    '.open { font-weight: 800; color: #157347; }',
    '.special { margin-top: 8px; padding: 8px 10px; border-radius: 8px; background: #ECFDF3; color: #067647; font-size: 13px; font-weight: 600; }',
    '.actions { display: flex; gap: 8px; padding: 0 16px 12px;  flex-wrap: wrap; }',
    '.btn { flex: 1; height: 36px; border-radius: 8px; border: 1px solid #D0D5DD; background: #fff; color: #101828; font: 600 13px/1 inherit; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; gap: 6px; white-space: nowrap; padding: 0 10px; }',
    '.btn.primary { background: #101828; color: #fff; border-color: #101828; }',
    '.btn.primary:hover { background: #1D2939; } .btn:hover { background: #F8FAFC; } .btn.primary:hover { background: #1D2939; }',
    '.btn svg { width: 14px; height: 14px; }',
    '.btn.done { background: #157347; border-color: #157347; color: #fff; }',
    '.foot { padding: 8px 16px 10px; border-top: 1px solid #EAECF0; font-size: 11px; color: #98A2B3; }',
    '.err { padding: 12px 16px 14px; font-size: 13px; color: #B42318; }',
    '.waitmsg { padding: 0 12px 0 0; font-size: 13px; color: #475467; white-space: nowrap; }',
    '.actions.stack .btn { flex: 1 1 100%; }',
    '.levers { margin: 12px 0 4px; } .levers .label { margin-bottom: 6px; } .lever { display: inline-flex; align-items: center; gap: 6px; margin: 0 8px 6px 0; padding: 5px 10px; border: 1px solid #D0D5DD; border-radius: 999px; font-size: 12.5px; color: #344054; cursor: pointer; background: #fff; } .lever.on { background: #DCFAE6; border-color: #ABEFC6; color: #067647; } .lever input { margin: 0; }',
    '.counter { margin: 10px 0 4px; } .counter summary { cursor: pointer; font-size: 13px; color: #344054; font-weight: 600; } .crow { display: flex; gap: 8px; margin-top: 8px; } .crow input { flex: 1; padding: 8px 10px; border: 1px solid #D0D5DD; border-radius: 8px; font-size: 13px; } .crow .btn { height: 34px; padding: 0 14px; font-size: 12.5px; } .cout { display: none; margin-top: 8px; font-size: 13px; color: #101828; background: #F8FAFC; border: 1px solid #EAECF0; border-radius: 8px; padding: 8px 10px; }',
    '.consent { margin: 0 16px 10px; padding: 10px 12px; border: 1px solid #EAECF0; border-radius: 10px; background: #F8FAFC; font-size: 12.5px; color: #344054; }',
    '.consent .cb { display: flex; gap: 8px; margin-top: 8px; }',
    '.consent .btn { height: 30px; font-size: 12px; flex: 0 0 auto; padding: 0 12px; }',
    '.share-toggle { display: inline-flex; align-items: center; gap: 6px; cursor: pointer; }',
    '.share-toggle i { width: 26px; height: 14px; border-radius: 7px; background: #D0D5DD; position: relative; display: inline-block; }',
    '.share-toggle i::after { content: ""; position: absolute; top: 2px; left: 2px; width: 10px; height: 10px; border-radius: 50%; background: #fff; transition: left .15s; }',
    '.share-toggle.on i { background: #157347; } .share-toggle.on i::after { left: 14px; }',
    '.foot { display: block; }',
    '.foot .disc { display: block; line-height: 1.45; margin: 0 0 7px; }',
    '.foot .links { display: flex; flex-wrap: wrap; align-items: center; gap: 6px 14px; }',
    '.foot .links .share-toggle { margin-left: auto; }',
    '.foot a { color: #475467; cursor: pointer; text-decoration: underline; white-space: nowrap; }',
    '.fb { padding: 10px 16px 12px; border-top: 1px solid #EAECF0; background: #F8FAFC; display: grid; gap: 8px; }',
    '.fb .label { margin-bottom: -2px; }',
    '.fb select, .fb input, .fb textarea { width: 100%; font: 13px inherit; padding: 7px 9px; border: 1px solid #D0D5DD; border-radius: 6px; background: #fff; color: #101828; }',
    '.fb textarea { min-height: 54px; resize: vertical; }',
    '.fb .row { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }',
    '.fb .btns2 { display: flex; gap: 8px; justify-content: flex-end; }',
    '.fb .btn { flex: 0 0 auto; height: 32px; font-size: 12px; }',
    '.fb .thanks { font-size: 13px; color: #067647; font-weight: 600; }'
  ].join('\n');

  var ICON = {
    mark: '<svg viewBox="0 0 24 24"><circle cx="8" cy="8" r="5" fill="#fff"/><circle cx="15.5" cy="14.5" r="3.6" fill="#157347"/><circle cx="20" cy="19" r="1.9" fill="#fff"/></svg>',
    minus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M5 12h14"/></svg>',
    plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
    x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>',
    share: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12v7a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-7M16 6l-4-4-4 4M12 2v13"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>'
  };

  function niceDate(d) { try { var x = new Date(d + 'T12:00:00'); return isNaN(x.getTime()) ? d : x.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }); } catch (e) { return d; } }
  function money(v) { return '$' + Math.round(v).toLocaleString('en-US'); }
  function h(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function t(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }

  var host = null, root = null;

  function consentBanner(card, ctx) {
    if (!ctx.opts || ctx.opts.consent !== null || typeof ctx.opts.onConsent !== 'function') return;
    var box = h('div', 'consent');
    var msg = t('div', null, 'Share what you browse and your estimates use this week\'s prices, not last month\'s. Listing facts from the pages you open and the search results you load; nothing about you, and never what you searched for. ');
    var wl = t('a', null, 'See exactly what is sent'); try { wl.href = chrome.runtime.getURL('welcome.html'); } catch (e) { wl.href = 'https://lowball.rent/privacy'; } wl.target = '_blank'; wl.rel = 'noopener'; msg.appendChild(wl); msg.appendChild(t('span', null, ' · '));
    var pl = t('a', null, 'Privacy policy'); pl.href = 'https://lowball.rent/privacy'; pl.target = '_blank'; pl.rel = 'noopener'; msg.appendChild(pl); box.appendChild(msg);
    var cb = h('div', 'cb'); var yes = h('button', 'btn primary', '<span>Share listings</span>'); var no = h('button', 'btn', '<span>No thanks</span>');
    yes.addEventListener('click', function () { ctx.opts.onConsent(true); ctx.opts.consent = true; box.remove(); syncToggle(card, true); });
    no.addEventListener('click', function () { ctx.opts.onConsent(false); ctx.opts.consent = false; box.remove(); syncToggle(card, false); });
    cb.appendChild(yes); cb.appendChild(no); box.appendChild(cb); card.appendChild(box);
  }
  function syncToggle(card, on) { var tg = card.querySelector('.share-toggle'); if (tg) { tg.classList.toggle('on', !!on); tg.title = on ? 'Sharing listing data (click to stop)' : 'Not sharing (click to share listings you view)'; } }

  function footer(card, text, ctx) {
    consentBanner(card, ctx);
    if (card.querySelector('.foot')) return;   // one footer per card, whatever calls us
    var foot = h('div', 'foot'); foot.appendChild(t('div', 'disc', text));
    var links = h('div', 'links'); foot.appendChild(links);
    var priv = t('a', null, 'Privacy'); priv.href = 'https://lowball.rent/privacy'; priv.target = '_blank'; priv.rel = 'noopener'; links.appendChild(priv);
    var terms = t('a', null, 'Terms'); terms.href = 'https://lowball.rent/terms'; terms.target = '_blank'; terms.rel = 'noopener'; links.appendChild(terms);
    if (ctx.opts && typeof ctx.opts.onConsent === 'function' && ctx.opts.consent !== null) {
      var tg = h('label', 'share-toggle' + (ctx.opts.consent === true ? ' on' : ''), '<i></i><span>Share data</span>');
      tg.addEventListener('click', function () { var on = !tg.classList.contains('on'); ctx.opts.onConsent(on); ctx.opts.consent = on; syncToggle(card, on); });
      links.appendChild(tg); syncToggle(card, ctx.opts.consent === true);
    }
    var a = t('a', null, 'Wrong? Flag it'); links.appendChild(a); card.appendChild(foot);
    var fb = null;
    a.addEventListener('click', function () {
      if (fb) { fb.remove(); fb = null; a.textContent = 'Wrong? Flag it'; return; }
      a.textContent = 'Close';
      fb = h('div', 'fb');
      fb.appendChild(t('div', 'label', 'Help improve the estimate'));
      var sel = h('select', null, ['What looks off?', 'Estimate too high', 'Estimate too low', 'Wrong beds, baths or size', 'Short-term or furnished, not a lease', 'Not actually for rent', 'Fees or price shown wrong', 'Other']
        .map(function (o, i) { return '<option' + (i ? '' : ' value="" disabled selected') + '>' + o + '</option>'; }).join(''));
      fb.appendChild(sel);
      var note = h('textarea'); note.placeholder = 'Anything else? (optional, 500 characters, no names or contact details please)'; note.maxLength = 500; fb.appendChild(note);
      var off = h('input'), acc = h('input');   // outcome amounts are collected by the follow-up card, not here
      if (ctx.opts && ctx.opts.installId) {
        var idrow = h('div', null); idrow.style.cssText = 'font-size:11px;color:#667085;display:flex;justify-content:space-between;align-items:center;gap:8px;';
        var idtxt = t('span', null, 'Install ID ' + ctx.opts.installId + ' (quote this to delete your shared data)'); idrow.appendChild(idtxt);
        var reset = t('a', null, 'Reset ID'); reset.style.cursor = 'pointer'; reset.style.textDecoration = 'underline';
        reset.addEventListener('click', function () { var nid = ctx.opts.onResetId ? ctx.opts.onResetId() : null; if (nid) { ctx.opts.installId = nid; idtxt.textContent = 'Install ID ' + nid + ' (new)'; } });
        idrow.appendChild(reset); fb.appendChild(idrow);
      }
      var btns = h('div', 'btns2'); var send = h('button', 'btn primary', '<span>Send</span>'); btns.appendChild(send); fb.appendChild(btns);
      send.addEventListener('click', function () {
        var num = function (el) { var v = Number(String(el.value).replace(/[^0-9.]/g, '')); return v > 0 ? v : null; };
        var body = { kind: num(acc) ? 'result' : 'flag', reason: sel.value || null, note: (note.value || '').slice(0, 500) || null, offered: num(off), accepted: num(acc),
                     url: ctx.pageUrl, listing: ctx.listing || {}, result: ctx.result || {}, install: ctx.opts && ctx.opts.installId || null, quote_id: ctx.result && ctx.result.quote_id || null };
        if (!body.reason && !body.note && !body.accepted && !body.offered) { sel.focus(); return; }
        (window.__lowballPost ? window.__lowballPost(ctx.api.replace('/score', '/flag'), body) : Promise.reject(new Error('no transport')))
          .then(function () { fb.innerHTML = ''; fb.appendChild(t('div', 'thanks', body.kind === 'result' ? 'Thanks. Real outcomes are what make this accurate.' : 'Thanks, logged for review.')); })
          .catch(function () { fb.appendChild(t('div', 'thanks', 'Could not reach the server.')); });
      });
      card.appendChild(fb);
    });
  }

  function mountHost() {
    var old = document.getElementById('lowball-panel'); if (old) old.remove();
    host = document.createElement('div'); host.id = 'lowball-panel';
    root = host.attachShadow({ mode: 'open' });
    var style = document.createElement('style'); style.textContent = CSS; root.appendChild(style);
    var dlgs = document.querySelectorAll('dialog:modal');
    (dlgs.length ? dlgs[dlgs.length - 1] : document.body).appendChild(host);
    return root;
  }

  function header(card, title, subtitle, opts) {
    var head = h('div', 'head');
    var mark = h('div', 'mark', ICON.mark); head.appendChild(mark);
    head.appendChild(t('span', 'wordmark', title));
    if (subtitle) head.appendChild(t('span', 'addr', subtitle));
    var btns = h('div', 'btns');
    if (!opts.noMin) {
      var min = h('button', 'ib', ICON.minus); min.title = 'Minimize';
      min.addEventListener('click', function () { card.classList.toggle('collapsed'); min.innerHTML = card.classList.contains('collapsed') ? ICON.plus : ICON.minus; });
      btns.appendChild(min);
    }
    var close = h('button', 'ib', ICON.x); close.title = 'Close';
    close.addEventListener('click', function () { opts.onClose && opts.onClose(); host.remove(); });
    btns.appendChild(close);
    head.appendChild(btns); card.appendChild(head);
  }

  function copyButton(label, icon, getText) {
    var b = h('button', 'btn' + (icon === 'copy' ? ' primary' : ''), ICON[icon] + '<span>' + label + '</span>');
    b.addEventListener('click', function () {
      var text = getText();
      var done = function () { b.classList.add('done'); b.innerHTML = ICON.check + '<span>Copied</span>'; setTimeout(function () { b.classList.remove('done'); b.innerHTML = ICON[icon] + '<span>' + label + '</span>'; }, 1800); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, function () { fallbackCopy(text); done(); });
      else { fallbackCopy(text); done(); }
    });
    return b;
  }
  function fallbackCopy(text) {
    var ta = document.createElement('textarea'); ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); } catch (e) {} ta.remove();
  }

  // Fair-housing rule: this letter and buildingMessage must never include or prompt for family status, children, disability,
  // national origin, religion, age, immigration status, or source of income, and must never generate landlord-facing text
  // (screening, reply, or pricing advice). Keep [Your name] and [Phone] as empty placeholders.
  // One letter, one number. The comps the panel shows go at the bottom so the landlord can check them. No fallback
  // figure: stating a second number in the same email tells the landlord the first one was never real.
  function sameBedComps(listing, r) { return (r.comps || []).filter(function (c) { return listing.beds == null || c.beds == null || c.beds === listing.beds; }); }
  // The three comps the letter cites: a cheaper unit in the same building first, then the lowest-priced similar units at or under asking.
  function letterComps(listing, r) {
    var cs = sameBedComps(listing, r); var bldg = cs.filter(function (c) { return c.same_building; });
    // the comps nearest the offer, at or under asking: an outlier at the bottom of the market makes the quoted range look silly
    var rest = cs.filter(function (c) { return !c.same_building && c.price <= (r.asking || Infinity) && !(c.days > 120); })
      .sort(function (a, b) { return Math.abs(a.price - r.offer) - Math.abs(b.price - r.offer); }).slice(0, 3 - bldg.length).sort(function (a, b) { return a.price - b.price; });
    return bldg.concat(rest).slice(0, 3);
  }
  function evidenceLine(listing, r, v) {
    var cs = letterComps(listing, r); if (cs.length < 2 && !cs.some(function (c) { return c.same_building; })) return null;
    var b = cs.filter(function (c) { return c.same_building; })[0];
    if (b) return b.addr + ' in this building' + (b.beds === listing.beds && b.sqft && listing.sqft && Math.abs(b.sqft - listing.sqft) < 60 ? ', the same size,' : '') + ' is listed on Zillow at ' + money(b.price) + (b.days ? ' after ' + b.days + ' days' : '') + ' as of ' + today();
    var lo = cs[0].price, hi = cs[cs.length - 1].price; var n = listing.beds != null ? (listing.beds === 0 ? 'studio' : listing.beds + '-bed') : 'similar';
    return ['similar ', 'comparable ', 'other '][v] + n + ' rentals nearby are listed at ' + (lo === hi ? money(lo) : money(lo) + ' to ' + money(hi)) + ' as of ' + today() + ' (below)';
  }
  function today() { return new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }); }
  function compLines(r, listing) {
    var cs = letterComps(listing, r); if (!cs.length) return [];
    return ['', 'Similar listings I looked at on Zillow, as of ' + today() + ':'].concat(cs.map(function (c) {
      return '- ' + (c.addr || 'Nearby, address not shown') + (c.beds != null ? ' · ' + c.beds + ' bd' : '') + (c.sqft ? ' · ' + c.sqft.toLocaleString() + ' sf' : '') + ' · ' + money(c.price) + (c.days != null ? (c.days === 0 ? ' · listed today' : ' · listed ' + c.days + ' days') : '');
    }));
  }
  function offerMessage(listing, r, ctx) {
    ctx = ctx || {};
    var v = Math.abs(Number(listing.zpid || 0) || (listing.address || '').length) % 3;   // vary the wording so the letter has no fingerprint phrase
    var n = listing.beds != null ? (listing.beds === 0 ? 'studio' : listing.beds + '-bed') : 'similar';
    var where = listing.address || 'your listing';
    if (/ · /.test(listing.address || '')) { var parts = listing.address.split(' · '); where = parts[1] + ' at ' + parts[0]; }   // "Unit 303 at Oceanhouse on Prospect"
    var zipOnly = !!r.zip_only;   // ZIP-wide comps are not evidence about this building; a leasing agent spots inland comps on an oceanfront unit instantly
    var nComps = sameBedComps(listing, r).length;
    var lines = ['Hi,', ''];
    if (r.ask_mode === 'concessions') {
      // Managed buildings rarely cut base rent without approval; leasing staff can give weeks free, waived fees, parking, or a better rate on a longer term the same day.
      lines.push(["I'm interested in ", "I'd like to tour ", "I'm looking at "][v] + where + [' and can tour this week. I have proof of income and references and can sign within 48 hours of approval.', ' and would like to see it this week. My proof of income and references are ready and I can sign quickly once approved.', '. I can tour any day this week, have my documents ready, and can sign as soon as I am approved.'][v]);
      var open = ctx.unitsOpen && ctx.unitsOpen > 1 ? ' I see ' + ctx.unitsOpen + ' ' + (listing.beds === 0 ? 'studios' : listing.beds + '-beds') + ' open right now, so I hope there is some room.' : '';
      if (r.special && r.special.desc) lines.push('', 'I saw the posted special (' + r.special.desc + '). Could you confirm it applies to this unit on a ' + r.special.lease_months + '-month term, and could you also waive the admin and application fees and include a parking space? If the unit has been sitting, an extra two weeks free would close it today.' + open);
      else lines.push('', 'If base rent is not flexible, my question is about move-in: could you do a month free, waive the admin and application fees, and include a parking space? I am open to a 13- or 14-month term if that improves the effective rate.' + open);
      var ev2 = zipOnly ? null : evidenceLine(listing, r, v); if (ev2) lines.push('', ['For reference, ', 'For context, ', 'As a comparison, '][v] + ev2 + '.');
      lines.push('', 'If that puts the net effective rate near ' + money(r.settle) + ', I will apply the same day.');
    } else {
      lines.push(["I'd like to rent ", "I'm interested in ", "I'd like to apply for "][v] + where + ' and can move in as soon as you need.');
      var evid = [];
      var ev = zipOnly ? null : evidenceLine(listing, r, v); if (ev) evid.push(ev);
      if (listing.days >= 21) evid.push('this listing shows ' + listing.days + ' days on Zillow');
      if (evid.length) lines.push('', evid.join(', and ').replace(/^./, function (ch) { return ch.toUpperCase(); }) + '.');
      var lv = ctx.levers || {}; var term = lv.longer ? '18-month' : '12-month';
      lines.push('', 'I can offer ' + money(r.offer) + ' a month on a ' + term + ' lease. ' + ['My application, proof of income, and references are ready, so you can decide quickly.', 'I have my application, proof of income, and references ready to send today.', 'Application, income verification, and references are ready whenever you want them.'][v]);
      var extras = [];
      if (lv.flexible) extras.push('I can move in on whatever date works for you, including right away, so you have no gap.');
      if (lv.longer) extras.push('An 18-month term means no turnover for you until ' + new Date(Date.now() + 548 * 86400000).getFullYear() + '.');
      if (lv.credit) extras.push('I can authorize a credit check or share a recent report with the application.');
      if (extras.length) lines.push('', extras.join(' '));
      lines.push('', ["If that doesn't work, tell me what would and I'll respond the same day.", "If that number doesn't work for you, let me know what would.", "Happy to talk if that isn't workable."][v]);
    }
    lines.push('', 'Thank you,', '[Your name]', '[Phone]');
    if (!zipOnly && letterComps(listing, r).length >= 2) lines = lines.concat(compLines(r, listing));
    return lines.join('\n');
  }

  function applyNote(listing, r) {
    var where = (listing.address || 'your listing') + (listing.city ? ' in ' + listing.city : '');
    return ['Hi,', '', "I'd like to apply for " + where + '. I can move in as soon as you need and can sign this week.',
            '', 'My application, proof of income, and references are ready. Could you send the application link and let me know the earliest date you could hand over keys?',
            '', 'Thank you,', '[Your name]', '[Phone]'].join('\n');
  }
  function approvedAsk(listing, r) {
    var n = listing.beds != null ? (listing.beds === 0 ? 'studio' : listing.beds + '-bed') : 'similar';
    var ev = evidenceLine(listing, r, 1);
    return ['Hi,', '', 'Thank you for approving my application for ' + (listing.address || 'the unit') + '.', '',
            (ev ? ev.replace(/^./, function (ch) { return ch.toUpperCase(); }) + '. ' : '') + 'Would you do ' + money(r.settle) + ' on a 12-month lease? I can sign today.',
            '', 'Thank you,', '[Your name]', '[Phone]'].concat(compLines(r, listing)).join('\n');
  }

  function buildingMessage(name, plans, unitsOpen, askMode) {
    // plans: [{label, asking, open, settle, comps, count}] one per floor plan or unit. One paragraph, never one per unit.
    var words = ['one', 'two', 'three', 'four', 'five', 'six'];
    var listed = plans.filter(function (p) { return p.asking; }).map(function (p) {
      var lab = (p.plan || p.label).replace(/ from$/, '').replace(/\s*\(.*?\)\s*/g, ' ').trim().replace(/\s*units?$/i, '').trim();
      return (p.count > 1 ? (words[p.count - 1] || p.count) + ' ' + lab.replace(/^the /, '') + ' units' : lab) + ' at ' + money(p.asking);
    });
    var listedText = listed.length > 1 ? listed.slice(0, -1).join(', ') + ' and ' + listed[listed.length - 1] : listed[0] || '';
    var lo = plans.reduce(function (a, p) { return (!a || (p.settle || p.open) < (a.settle || a.open)) ? p : a; }, null);
    var total = unitsOpen && unitsOpen > plans.length ? unitsOpen : plans.reduce(function (n, p) { return n + (p.count || 1); }, 0);
    var lines = ['Hi,', '', "I'm interested in " + name + ' and can tour this week. I have proof of income and references and can sign within 48 hours of approval.'];
    if (listedText) lines.push('', 'I see ' + (total > 1 ? total + ' units open' : 'the listing') + ': ' + listedText + '.');
    if (askMode === 'concessions') {
      lines.push('', 'If base rent is not flexible, my question is about move-in: could you do a month free, waive the admin and application fees, and include a parking space? I am open to a 13- or 14-month term if that improves the effective rate.');
      if (lo) lines.push('', 'If that puts the net effective rate near ' + money(lo.settle || lo.open) + ' on the ' + (lo.plan || lo.label).replace(/ from$/, '') + ', I will apply the same day.');
    } else if (lo) {
      var loLab = (lo.plan || lo.label).replace(/ from$/, '').replace(/\s*\(.*?\)\s*/g, ' ').replace(/^the /, '').trim();
      lines.push('', 'Would you do ' + money(lo.open) + ' a month on a 12-month lease for ' + (/^unit/i.test(loLab) ? loLab : 'the ' + loLab) + '? With ' + (total > 1 ? total + ' units open' : 'the unit open') + ' I hope there is some room, and I can sign this week. If not, what would work?');
    }
    lines.push('', 'Thank you,', '[Your name]', '[Phone]');
    return lines.join('\n');
  }

  function shareText(listing, r, url) {
    return 'Lowball\'s estimate: offer ' + money(r.offer) + ' on this ' + money(r.asking) + '/mo listing' + (listing.city ? ' in ' + listing.city : '') +
      ' (fair rent ~' + money(r.fair) + ', likely to land near ' + money(r.settle) + '). ' + url + '\nGet the extension: lowball.rent';
  }

  // The cut prediction, as a lead line. cut_share and extra_days are well measured in every age band; p_cut_next is
  // not. Past 60 days the cross-section cannot see it, because listings that cut and then rented have left the stock,
  // so the fitted hazard collapses to 0 and the server floors it at the 31-60 day value. Show the hazard only where it
  // is actually measured (under 61 days) and lead on cut_share everywhere else.
  function predictionLine(listing, r) {
    var days = listing.days || 0, cb = r.cut_band, bits = [];
    if (r.last_cut) bits.push('Cut ' + money(r.last_cut.from - r.last_cut.to) + (r.last_cut.date ? ' on ' + niceDate(r.last_cut.date) : '') + (r.last_cut.n > 1 ? ' (' + r.last_cut.n + ' cuts)' : ''));
    if (days >= 8) bits.push(days + ' days listed');
    if (cb && cb.cut_share != null && (cb.n || 0) >= 30 && days >= 8) {
      var s = Math.round(cb.cut_share * 100) + '% of listings like this have already cut';
      if (cb.cut_p50) s += ', typically ' + Math.round(cb.cut_p50) + '%';
      bits.push(s);
    }
    if (cb && cb.p_cut_next > 0.02 && days >= 8 && days < 61) bits.push('about ' + Math.round(cb.p_cut_next * 100) + '% cut again within a month');
    else if (cb && cb.extra_days && days >= 31) bits.push('another ' + Math.round(cb.extra_days) + ' days empty is ' + money(r.asking * cb.extra_days / 30) + ' the owner never gets back');
    else if (r.last_cut) bits.push('landlords who have cut once cut again');
    else if (days >= 31) bits.push('every empty month costs them a month of rent');
    return bits.length >= 2 ? bits.join(' \u00b7 ') : '';
  }

  var UI = {
    score: function (listing, r, opts) {
      var root = mountHost();
      var card = h('div', 'card ' + r.leverage); header(card, 'Lowball', listing.address || ('zpid ' + listing.zpid), opts);
      var body = h('div', 'body');
      var mode = r.short_term ? 'short' : r.fresh ? 'fresh' : r.ask_mode === 'concessions' ? 'concessions' : r.saving_month > 0 ? 'offer' : 'fair';
      // Lead with what is going to happen to this listing, not with our estimate of it. That prediction is the one
      // output nobody can get for free, and it answers the renter's actual question: negotiate now, or wait.
      var pred = predictionLine(listing, r);
      if (pred) { var pl = h('div', 'sub lead'); pl.style.cssText = 'margin:0 0 8px;color:#1D2939;font-weight:600'; pl.textContent = pred; body.appendChild(pl); }
      if (mode === 'fresh') {
        // A days-old listing with no cut yet: offering under asking now risks the unit. Apply, then ask once approved.
        body.appendChild(t('div', 'label', 'Fresh listing (' + (listing.days || 0) + ' days). Apply at'));
        body.appendChild(t('div', 'big', money(r.asking)));
        body.appendChild(t('div', 'sub', 'Offering under asking this early can cost you the unit. Once approved, ask for ' + money(r.settle) + '.'));
        var land = h('div', 'land'); land.appendChild(t('span', null, 'Or offer now, knowing the risk')); land.appendChild(t('b', null, money(r.offer))); body.appendChild(land);
      } else if (mode === 'concessions') {
        body.appendChild(t('div', 'label', 'Target effective rent'));
        body.appendChild(t('div', 'big', money(r.offer)));
        if (r.special && r.special.effective) body.appendChild(t('div', 'sub', 'Posted special: ' + r.special.desc + (r.special.upper_bound ? ' (up to)' : '') + ' · about ' + money(r.special.effective) + '/mo effective on ' + r.special.lease_months + ' months. Lock it, then add fees and parking.'));
        else body.appendChild(t('div', 'sub', 'About a month free on a 13-month lease plus waived fees · ' + money(r.saving_month * 13) + ' over a 13-month lease'));
        if (r.saving_month > 0) { var yrc = t('div', 'sub', money(r.saving_month * 12) + ' a year off the effective rate'); yrc.style.cssText = 'margin:2px 0 0;color:#157347;font-weight:700;font-size:14px'; body.appendChild(yrc); }
      } else if (r.data_tier === 'none' || r.data_tier === 'range') {
        // Thin local data: a range with the count visible, never a confident-looking single number. The offer stays, as a secondary line.
        var lo = r.interval && r.interval[0] ? r.interval[0] : Math.round(r.fair * (r.data_tier === 'none' ? 0.8 : 0.87) / 25) * 25, hi = r.interval && r.interval[1] ? r.interval[1] : Math.round(r.fair * (r.data_tier === 'none' ? 1.2 : 1.13) / 25) * 25;
        body.appendChild(t('div', 'label', r.data_tier === 'none' ? 'Not enough nearby data yet. Rough range' : 'Rough range from ' + r.local_rows + ' nearby listings'));
        body.appendChild(t('div', 'big', money(lo) + ' \u2013 ' + money(hi)));
        body.appendChild(t('div', 'sub', (r.data_tier === 'none' ? 'From a public rent index for this ZIP, not from listings we hold. ' : 'Few listings here, some may be months old. ') + 'Treat this as a range, not a number. Sharing the listings you view fills this area in.'));
        var land3 = h('div', 'land'); land3.appendChild(t('span', null, 'If you name a number, open near')); land3.appendChild(t('b', null, money(r.offer))); body.appendChild(land3);
      } else {
        body.appendChild(t('div', 'label', mode === 'short' ? 'Ask for a long-term rate near' : mode === 'offer' ? 'Offer this' : 'Fair price. Offer'));
        body.appendChild(t('div', 'big', money(r.offer)));
        if (r.settle_saving_month > 0) {
          var yrAmt2 = r.settle_saving_month * 12;
          var yr = t('div', 'sub', money(yrAmt2) + ' a year below asking, if it lands near ' + money(r.settle));
          if (yrAmt2 >= 600) yr.style.cssText = 'margin:2px 0 0;color:#157347;font-weight:700;font-size:14px';
          body.appendChild(yr);
        } else body.appendChild(t('div', 'sub', 'Asking is at or below market, so open close to it.'));
        var land2 = h('div', 'land'); land2.appendChild(t('span', null, 'Likely to settle at')); land2.appendChild(t('b', null, money(r.settle)));
        if (r.settle_saving_month > 0) land2.appendChild(t('span', null, money(r.settle_saving_month) + '/mo off'));
        body.appendChild(land2);
      }
      var stats = h('div', 'stats');
      var nC = (r.comps || []).length;
      [['Asking', money(r.asking)], [nC >= 3 ? (r.zip_only ? 'Same ZIP (' + nC + ')' : 'Similar nearby (' + nC + ')') : 'Similar nearby', r.comps_median ? money(r.comps_median) : 'few comps'], ['Typical asking', money(r.fair)]].forEach(function (kv) {
        var s = h('div', 'stat'); s.appendChild(t('div', 'label', kv[0])); s.appendChild(t('div', 'v', kv[1])); stats.appendChild(s);
      });
      body.appendChild(stats);
      var how = h('details'); how.appendChild(t('summary', null, 'How we got this'));
      how.appendChild(t('div', 'sub', r.national ? 'Outside our modeled area: typical asking comes from a public rent index for this ZIP, adjusted for bedrooms, size, and home type. Lower confidence.' : 'Typical asking comes from a model of similar active listings nearby (beds, baths, size, year, location, type) blended with the comparable rentals below. It is what similar listings ask, not an appraisal.'));
      if (r.interval && r.interval.length === 2 && r.interval[1] > r.interval[0]) how.appendChild(t('div', 'sub', '80% of units like this ask between ' + money(r.interval[0]) + ' and ' + money(r.interval[1]) + '.'));
      if (listing.zillow_shown) how.appendChild(t('div', 'sub', 'Zillow\'s own estimate is ' + money(listing.zillow_shown) + '. It is not an input to ours.'));
      body.appendChild(how);
      if (opts.firstHint) { var hint = t('div', 'sub hint', 'These numbers are Lowball\'s, built from nearby listings. They are not Zillow\'s.'); hint.style.cssText = 'background:#FEF0C7;border:1px solid #FEDF89;color:#7A2E0E;border-radius:8px;padding:6px 10px;margin:6px 0'; body.insertBefore(hint, body.firstChild); }
      if (opts.costs && (opts.costs.deposit || opts.costs.move_in || opts.costs.application || (opts.costs.total_monthly && opts.costs.base && opts.costs.total_monthly !== opts.costs.base))) {
        // The listing's own numbers, shown as posted. Nothing here is estimated.
        var cs = opts.costs, det0 = h('details'); det0.open = true; det0.appendChild(t('summary', null, 'Costs posted on the listing'));
        var tb0 = h('table');
        [['Base rent', cs.base], ['Total monthly with required fees', cs.total_monthly && cs.total_monthly !== cs.base ? cs.total_monthly : null], ['Security deposit', cs.deposit], ['Holding deposit', cs.holding], ['Application', cs.application], ['Move-in cost', cs.move_in]]
          .forEach(function (kv) { if (!kv[1]) return; var tr = h('tr'); tr.appendChild(t('td', null, kv[0])); tr.appendChild(t('td', 'n', money(kv[1]))); tb0.appendChild(tr); });
        det0.appendChild(tb0); body.appendChild(det0);
      }
      var meter = h('div', 'meter'); var segs = h('div', 'segs'); for (var i = 0; i < 3; i++) segs.appendChild(h('div', 'seg'));
      meter.appendChild(segs); var mt = t('div', 't', 'Leverage '); mt.appendChild(t('b', null, String(r.leverage))); mt.appendChild(document.createTextNode(' · confidence ' + String(r.confidence))); meter.appendChild(mt); body.appendChild(meter);
      var why = h('ul', 'why');
      (r.signals || []).forEach(function (s) { var li = t('li', /short-term|hidden|only \d|imputed|no square/i.test(s) ? 'warn' : null, s); why.appendChild(li); });
      body.appendChild(why);
      if (r.comps && r.comps.length) {
        var det = h('details'); det.open = !r.zip_only; det.appendChild(t('summary', null, r.comps.length + (r.zip_only ? ' rentals in the same ZIP (location not exact)' : ' comparable rentals nearby')));
        var tb = h('table'); var tr0 = h('tr'); ['Address', 'Rent', 'Size', 'Days'].forEach(function (x, i) { tr0.appendChild(t('th', i ? 'n' : null, x)); }); tb.appendChild(tr0);
        r.comps.forEach(function (c) {
          var tr = h('tr'); tr.appendChild(t('td', null, c.addr || 'Hidden address')); tr.appendChild(t('td', 'n', money(c.price)));
          tr.appendChild(t('td', 'n', c.sqft ? c.sqft.toLocaleString() + ' sf' : '')); tr.appendChild(t('td', 'n', c.days != null ? c.days + 'd' : '')); tb.appendChild(tr);
        });
        det.appendChild(tb); body.appendChild(det);
      }
      if (opts.others && opts.others.length) {
        var det2 = h('details'); det2.open = true;
        det2.appendChild(t('summary', null, (opts.available && opts.available > opts.others.length + 1 ? opts.available + ' units available · ' : '') + opts.others.length + ' other listed'));
        var tb2 = h('table'); var trh = h('tr'); ['Unit', 'Asking', r.ask_mode === 'concessions' ? 'Target' : 'Offer'].forEach(function (x, i) { trh.appendChild(t('th', i ? 'n' : null, x)); }); tb2.appendChild(trh);
        opts.others.forEach(function (o) { var tr = h('tr'); tr.appendChild(t('td', null, o.label)); tr.appendChild(t('td', 'n', o.asking ? money(o.asking) : 'ask')); tr.appendChild(t('td', 'n open', (o.asking ? '' : '~') + money(o.open))); tb2.appendChild(tr); });
        det2.appendChild(tb2); body.appendChild(det2);
      }
      // Levers: each is worth real money to a landlord and never gets said unless prompted. They only change the letter.
      var levers = opts.levers || (opts.levers = {});
      if (!r.short_term && r.ask_mode !== 'concessions') {
        var lvBox = h('div', 'levers'); lvBox.appendChild(t('div', 'label', 'What you can offer besides money'));
        [['flexible', 'Flexible move-in'], ['longer', '18-month lease'], ['credit', 'Credit check ready']].forEach(function (kv) {
          var lab = h('label', 'lever' + (levers[kv[0]] ? ' on' : ''), '<input type="checkbox"' + (levers[kv[0]] ? ' checked' : '') + '><span>' + kv[1] + '</span>');
          lab.querySelector('input').addEventListener('change', function (e) { levers[kv[0]] = e.target.checked; lab.classList.toggle('on', e.target.checked); });
          lvBox.appendChild(lab);
        });
        body.appendChild(lvBox);
      }
      // Counter reply: the landlord answered with a number. Is it a take, a split, or a hold?
      if (!r.short_term) {
        var cbox = h('details', 'counter'); cbox.appendChild(t('summary', null, 'They countered? Check the number'));
        var crow = h('div', 'crow'); var cin = h('input'); cin.placeholder = 'Their counter, e.g. ' + money(Math.round((r.offer + r.asking) / 2)); cin.inputMode = 'numeric';
        var cgo = h('button', 'btn primary', '<span>Check</span>'); var cout = h('div', 'cout');
        cgo.addEventListener('click', function () {
          var v = Number(String(cin.value).replace(/[^0-9.]/g, '')); if (!(v > 0)) { cin.focus(); return; }
          var msg;
          if (v <= r.offer) msg = 'Better than your opener. Take it before they rethink it.';
          else if (v <= r.settle) msg = 'Inside the likely landing range (' + money(r.offer) + ' to ' + money(r.settle) + '). Take it, or ask for one small thing on top: a later start date, a repair, parking.';
          else if (v < r.asking) { var mid = Math.round(((v + r.settle) / 2) / 25) * 25; msg = 'Above the likely range. Split it: say you can do ' + money(mid) + ' and sign this week. ' + (r.at_or_below ? r.at_or_below + ' similar units are listed at or below your offer, so you have somewhere to go.' : ''); }
          else msg = 'That is asking. They have not moved. Hold at ' + money(r.settle) + ' with the comps, or move on: ' + (r.at_or_below ? r.at_or_below + ' similar units are listed at or below your offer.' : 'there are other listings.');
          cout.textContent = msg; cout.style.display = 'block';
          if (opts.onCounter) opts.onCounter(v, listing, r);
        });
        crow.appendChild(cin); crow.appendChild(cgo); cbox.appendChild(crow); cbox.appendChild(cout); body.appendChild(cbox);
      }
      card.appendChild(body);
      var actions = h('div', 'actions');
      var sameBedOpen = 1 + (opts.others || []).filter(function (o) { return o.beds === listing.beds; }).length;
      if (r.fresh && !r.short_term) {
        actions.className = 'actions stack';
        actions.appendChild(copyButton('Copy application note', 'copy', function () { if (opts.onEvent) opts.onEvent('copy_apply', listing.zpid || listing.address, listing, r); return applyNote(listing, r); }));
        actions.appendChild(copyButton('Copy the once-approved ask (' + money(r.settle) + ')', 'copy', function () { if (opts.onEvent) opts.onEvent('copy_approved_ask', listing.zpid || listing.address, listing, r); return approvedAsk(listing, r); }));
        actions.appendChild(copyButton('Copy an offer now (' + money(r.offer) + ', risky)', 'copy', function () { if (opts.onEvent) opts.onEvent('copy_offer', listing.zpid || listing.address, listing, r); return offerMessage(listing, r, { unitsOpen: sameBedOpen, levers: levers }); }));
      } else {
        actions.appendChild(copyButton(r.ask_mode === 'concessions' ? 'Copy inquiry' : 'Copy offer', 'copy', function () {
          if (opts.onEvent) opts.onEvent(r.ask_mode === 'concessions' ? 'copy_inquiry' : 'copy_offer', listing.zpid || listing.address, listing, r);
          return offerMessage(listing, r, { unitsOpen: sameBedOpen, levers: levers });
        }));
      }
      card.appendChild(actions); card.appendChild(t('div', 'sub', 'Check that the comps are still listed before you send. You are responsible for what you send.')).style.padding = '0 16px 10px';
      footer(card, (r.national ? 'Estimate from a public rent index for this ZIP, lower confidence. ' : 'Typical asking is what similar active listings ask, not an appraisal or what a landlord will accept. San Diego County data' + (r.data_asof ? ', as of ' + r.data_asof : '') + '. ') + 'Not legal, financial, or real-estate advice. No guarantee. Not affiliated with Zillow.', { api: opts.api, pageUrl: opts.pageUrl, listing: listing, result: r, opts: opts });
      root.appendChild(card);
    },

    estimate: function (listing, r, opts) {
      var root = mountHost();
      var card = h('div', 'card medium'); header(card, 'Lowball', listing.address, opts);
      var body = h('div', 'body');
      body.appendChild(t('div', 'label', 'No price posted. Expect around'));
      body.appendChild(t('div', 'big', money(r.fair)));
      body.appendChild(t('div', 'sub', 'Likely range ' + money(r.range_low) + ' to ' + money(r.range_high) + ' for a ' + listing.beds + ' bed' + (listing.sqft ? ', ' + listing.sqft.toLocaleString() + ' sq ft' : '')));
      var land = h('div', 'land'); land.appendChild(t('span', null, 'If they quote above that, open at')); land.appendChild(t('b', null, money(r.offer))); body.appendChild(land);
      var stats = h('div', 'stats');
      [['Model', r.model ? money(r.model) : 'n/a'], ['Comps median', r.comps_median ? money(r.comps_median) : 'n/a'], ['Comps found', String((r.comps || []).length)]].forEach(function (kv) {
        var s = h('div', 'stat'); s.appendChild(t('div', 'label', kv[0])); s.appendChild(t('div', 'v', kv[1])); stats.appendChild(s);
      });
      body.appendChild(stats);
      var why = h('ul', 'why'); (r.signals || []).forEach(function (s) { why.appendChild(t('li', /only \d|no similar|no square|zip/i.test(s) ? 'warn' : null, s)); }); body.appendChild(why);
      if (r.comps && r.comps.length) {
        var det = h('details'); det.open = !r.zip_only; det.appendChild(t('summary', null, r.comps.length + (r.zip_only ? ' rentals in the same ZIP (location not exact)' : ' comparable rentals nearby')));
        var tb = h('table'); var tr0 = h('tr'); ['Address', 'Rent', 'Size', 'Days'].forEach(function (x, i) { tr0.appendChild(t('th', i ? 'n' : null, x)); }); tb.appendChild(tr0);
        r.comps.forEach(function (c) { var tr = h('tr'); tr.appendChild(t('td', null, c.addr || 'Hidden address')); tr.appendChild(t('td', 'n', money(c.price))); tr.appendChild(t('td', 'n', c.sqft ? c.sqft.toLocaleString() + ' sf' : '')); tr.appendChild(t('td', 'n', c.days != null ? c.days + 'd' : '')); tb.appendChild(tr); });
        det.appendChild(tb); body.appendChild(det);
      }
      if (opts.others && opts.others.length) {
        var det2 = h('details'); det2.open = true;
        det2.appendChild(t('summary', null, (opts.available && opts.available > opts.others.length + 1 ? opts.available + ' units available · ' : '') + opts.others.length + ' other listed'));
        var tb2 = h('table'); var trh = h('tr'); ['Unit', 'Asking', r.ask_mode === 'concessions' ? 'Target' : 'Offer'].forEach(function (x, i) { trh.appendChild(t('th', i ? 'n' : null, x)); }); tb2.appendChild(trh);
        opts.others.forEach(function (o) { var tr = h('tr'); tr.appendChild(t('td', null, o.label)); tr.appendChild(t('td', 'n', o.asking ? money(o.asking) : 'ask')); tr.appendChild(t('td', 'n open', (o.asking ? '' : '~') + money(o.open))); tb2.appendChild(tr); });
        det2.appendChild(tb2); body.appendChild(det2);
      }
      card.appendChild(body);
      var actions = h('div', 'actions');
      actions.appendChild(copyButton('Copy inquiry', 'copy', function () {
        return ['Hi,', '', 'I\'m interested in ' + listing.address + '. Could you send me today\'s rate for a 12-month lease, the earliest move-in date, and any current specials?',
                'Comparable ' + listing.beds + '-bedroom units nearby are renting around ' + money(r.fair) + ', so that\'s the range I\'m working with. I have proof of income and references ready and can tour this week.', '', 'Thank you,', '[Your name]', '[Phone]'].join('\n');
      }));
      actions.appendChild(copyButton('Share', 'share', function () { return 'Lowball estimate for ' + listing.address + ': about ' + money(r.fair) + '/mo (' + money(r.range_low) + ' to ' + money(r.range_high) + '). ' + opts.pageUrl + '\nGet the extension: lowball.rent'; }));
      card.appendChild(actions);
      footer(card, 'The building sets the real number. Estimates are not advice or a guarantee. Not affiliated with Zillow.', { api: opts.api, pageUrl: opts.pageUrl, listing: listing, result: r, opts: opts });
      root.appendChild(card);
    },

    range: function (b, x, opts) {
      var root = mountHost();
      var lev = (x.lo.r.leverage === 'high' || x.hi.r.leverage === 'high') ? 'high' : (x.lo.r.leverage === 'medium' || x.hi.r.leverage === 'medium') ? 'medium' : 'low';
      var card = h('div', 'card ' + lev); header(card, 'Lowball', b.name, opts);
      var body = h('div', 'body');
      body.appendChild(t('div', 'label', x.lo.r.ask_mode === 'concessions' ? 'Target effective rent, by unit' : 'Offer, by unit'));
      body.appendChild(t('div', 'big', money(x.lo.r.offer) + (x.hi.r.offer !== x.lo.r.offer ? ' – ' + money(x.hi.r.offer) : '')));
      body.appendChild(t('div', 'sub', 'Asking ' + money(x.lo.u.price) + ' to ' + money(x.hi.u.price) + ' across ' + b.units.length + ' listed units'));
      if (x.lo.r.special && x.lo.r.special.effective && x.hi.r.special && x.hi.r.special.effective) body.appendChild(t('div', 'sub', 'With the posted special (' + x.lo.r.special.desc + '): about ' + money(x.lo.r.special.effective) + ' to ' + money(x.hi.r.special.effective) + ' a month effective on ' + x.lo.r.special.lease_months + ' months.'));
      var land = h('div', 'land'); land.appendChild(t('span', null, 'Likely to settle at')); land.appendChild(t('b', null, money(x.lo.r.settle) + (x.hi.r.settle !== x.lo.r.settle ? ' – ' + money(x.hi.r.settle) : ''))); body.appendChild(land);
      var tb = h('table', 'units'); var tr0 = h('tr'); ['Unit', 'Asking', 'Offer', 'Likely'].forEach(function (s, i) { tr0.appendChild(t('th', i ? 'n' : null, s)); }); tb.appendChild(tr0);
      (opts.rows || []).forEach(function (o) { var tr = h('tr'); tr.appendChild(t('td', null, o.label)); tr.appendChild(t('td', 'n', o.asking ? money(o.asking) : 'ask')); tr.appendChild(t('td', 'n open', (o.asking ? '' : '~') + money(o.open))); tr.appendChild(t('td', 'n', o.settle ? money(o.settle) : '')); tb.appendChild(tr); });
      tb.style.marginTop = '12px'; body.appendChild(tb);
      var meter = h('div', 'meter'); var segs = h('div', 'segs'); for (var i = 0; i < 3; i++) segs.appendChild(h('div', 'seg'));
      meter.appendChild(segs); var mt2 = t('div', 't', 'Leverage '); mt2.appendChild(t('b', null, String(lev))); meter.appendChild(mt2); meter.style.marginTop = '12px'; body.appendChild(meter);
      var why = h('ul', 'why'); (x.lo.r.signals || []).forEach(function (s) { why.appendChild(t('li', null, s)); });
      why.appendChild(t('li', null, 'Click a unit to see its own estimate. The lowest-priced unit matches the low end of this range.'));
      body.appendChild(why); card.appendChild(body);
      var actions = h('div', 'actions');
      actions.appendChild(copyButton('Copy inquiry', 'copy', function () { return buildingMessage(b.name, (opts.rows || []).map(function (o) { return { label: o.label.replace(/ · .*$/, ''), plan: o.plan, count: o.count, asking: o.asking, open: o.open, settle: o.settle, comps: o.comps }; }), b.available, x.lo.r.ask_mode); }));
      actions.appendChild(copyButton('Share', 'share', function () { return 'Lowball\'s estimate for ' + b.name + ': offer ' + money(x.lo.r.offer) + ' to ' + money(x.hi.r.offer) + ' vs asking ' + money(x.lo.u.price) + ' to ' + money(x.hi.u.price) + '. ' + opts.pageUrl + '\nGet the extension: lowball.rent'; }));
      card.appendChild(actions);
      footer(card, 'Unit list from this page. Estimates are not advice or a guarantee. Not affiliated with Zillow.', { api: opts.api, pageUrl: opts.pageUrl, listing: { address: b.name, units: b.units }, result: x.lo.r, opts: opts });
      root.appendChild(card);
    },

    building: function (b, results, opts) {
      var root = mountHost();
      var lev = results.some(function (r) { return r.leverage === 'high'; }) ? 'high' : results.some(function (r) { return r.leverage === 'medium'; }) ? 'medium' : 'low';
      var card = h('div', 'card ' + lev); header(card, 'Lowball', b.name, opts);
      var body = h('div', 'body');
      body.appendChild(t('div', 'label', b.units.length + ' unit' + (b.units.length > 1 ? 's' : '') + ' listed' + (b.available > b.units.length ? ' · ' + b.available + ' available' : '')));
      if (b.special) body.appendChild(t('div', 'special', 'Posted special: ' + b.special));
      var tb = h('table', 'units'); var tr0 = h('tr'); ['Unit', 'Asking', 'Offer', 'Likely'].forEach(function (x, i) { tr0.appendChild(t('th', i ? 'n' : null, x)); }); tb.appendChild(tr0);
      b.units.forEach(function (u, i) {
        var r = results[i]; var tr = h('tr');
        tr.appendChild(t('td', null, (u.unit ? 'Unit ' + u.unit + ' · ' : '') + u.beds + 'bd/' + u.baths + 'ba' + (u.sqft ? ' · ' + u.sqft + ' sf' : '')));
        tr.appendChild(t('td', 'n', u.por ? 'ask' : money(u.price))); tr.appendChild(t('td', 'n open', u.por ? '~' + money(r.fair) : money(r.offer))); tr.appendChild(t('td', 'n', money(r.settle))); tb.appendChild(tr);
      });
      body.appendChild(tb);
      var meter = h('div', 'meter'); var segs = h('div', 'segs'); for (var i = 0; i < 3; i++) segs.appendChild(h('div', 'seg'));
      meter.appendChild(segs); var mt2 = t('div', 't', 'Leverage '); mt2.appendChild(t('b', null, String(lev))); meter.appendChild(mt2); meter.style.marginTop = '12px'; body.appendChild(meter);
      var why = h('ul', 'why');
      (results[0].signals || []).forEach(function (s) { why.appendChild(t('li', null, s)); });
      why.appendChild(t('li', null, 'Ask for concessions (weeks free, waived fees, parking) rather than a lower base rent, and ask which units have sat longest.'));
      body.appendChild(why); card.appendChild(body);
      var actions = h('div', 'actions');
      var best = results.reduce(function (a, r, i) { return ((r.saving_month || 0) > (results[a].saving_month || 0)) ? i : a; }, 0);
      actions.appendChild(copyButton('Copy offer', 'copy', function () {
        var u = b.units[best], r = results[best];
        return offerMessage({ address: b.name + (u.unit ? ', Unit ' + u.unit : ''), beds: u.beds, days: 0 }, r) + (b.special ? '\n\nI saw there is a current special and would like to apply it to this offer.' : '');
      }));
      actions.appendChild(copyButton('Share', 'share', function () { return 'Lowball\'s estimate for ' + b.name + ': open at ' + money(results[best].offer) + ' vs ' + money(b.units[best].price) + ' asking. ' + opts.pageUrl + '\nGet the extension: lowball.rent'; }));
      card.appendChild(actions);
      footer(card, 'Unit list read from this page. Estimates are not advice or a guarantee. Not affiliated with Zillow.', { api: opts.api, pageUrl: opts.pageUrl, listing: { address: b.name, units: b.units }, result: results[0], opts: opts });
      root.appendChild(card);
    },

    error: function (listing, msg, opts) {
      var root = mountHost();
      var card = h('div', 'card low'); header(card, 'Lowball', listing && listing.address, Object.assign({ noMin: true }, opts));
      card.appendChild(t('div', 'err', msg));
      if (opts && opts.onRetry) { var a = h('div', 'actions'); var b = h('button', 'btn primary', '<span>Retry</span>'); b.addEventListener('click', function () { opts.onRetry(); }); a.appendChild(b); card.appendChild(a); }
      root.appendChild(card);
    },

    // A week after a letter is copied: what happened? One tap. This is the only data that can check the numbers.
    followup: function (item, opts) {
      var root = mountHost(); host.setAttribute('data-state', 'followup'); host.classList.remove('lb-waiting');
      var card = h('div', 'card medium'); header(card, 'Lowball', item.address || 'your listing', opts);
      var body = h('div', 'body');
      var what = item.kind === 'copy_apply' ? 'an application note' : item.kind === 'copy_approved_ask' ? 'the once-approved ask at ' + money(item.settle) : item.kind === 'copy_inquiry' ? 'a concession inquiry near ' + money(item.settle) : 'an offer at ' + money(item.offer);
      var days = Math.max(1, Math.round((Date.now() - item.at) / 86400000));
      body.appendChild(t('div', 'label', 'Quick check'));
      body.appendChild(t('div', 'sub', 'You copied ' + what + ' for this listing ' + days + ' day' + (days === 1 ? '' : 's') + ' ago. What happened?'));
      var grid = h('div', 'btns2'); grid.style.flexWrap = 'wrap'; grid.style.gap = '6px';
      var amountRow = h('div'); amountRow.style.display = 'none'; amountRow.style.margin = '8px 0';
      var amt = h('input'); amt.placeholder = 'Monthly rent they said, e.g. 2650'; amt.style.cssText = 'width:100%;box-sizing:border-box;padding:8px;border:1px solid #D0D5DD;border-radius:8px;font-size:13px';
      var go = h('button', 'btn primary', '<span>Save</span>'); go.style.marginTop = '6px'; amountRow.appendChild(amt); amountRow.appendChild(go);
      var pending = null;
      function answer(kind, amount) { opts.onAnswer && opts.onAnswer(kind, amount); body.innerHTML = ''; body.appendChild(t('div', 'thanks', kind === 'accepted' ? 'Nice. That number goes straight into making the estimates better.' : 'Thanks. Real outcomes are what make this accurate.')); setTimeout(function () { host.remove(); opts.onDone && opts.onDone(); }, 1800); }
      [['accepted', 'They accepted'], ['countered', 'They countered'], ['declined', 'They said no'], ['no_reply', 'No reply'], ['gone', 'Unit was gone'], ['not_sent', "Didn't send it"]].forEach(function (kv) {
        var b = h('button', 'btn', '<span>' + kv[1] + '</span>'); b.style.flex = '1 1 45%';
        b.addEventListener('click', function () {
          if (kv[0] === 'accepted' || kv[0] === 'countered') { pending = kv[0]; amountRow.style.display = 'block'; amt.placeholder = (kv[0] === 'accepted' ? 'Rent you agreed to, e.g. ' : 'Their counter, e.g. ') + (item.settle || 2500); amt.focus(); return; }
          answer(kv[0], null);
        });
        grid.appendChild(b);
      });
      go.addEventListener('click', function () { var v = Number(String(amt.value).replace(/[^0-9.]/g, '')); answer(pending, v > 0 ? v : null); });
      body.appendChild(grid); body.appendChild(amountRow);
      var later = t('a', null, 'Ask me later'); later.href = '#'; later.style.cssText = 'display:inline-block;margin-top:8px;font-size:12px;color:#667085'; later.addEventListener('click', function (e) { e.preventDefault(); host.remove(); opts.onLater && opts.onLater(); });
      body.appendChild(later); card.appendChild(body);
      footer(card, 'Outcomes are stored without your name or the address. Not affiliated with Zillow.', { api: opts.api, pageUrl: opts.pageUrl, listing: { address: item.address }, result: {}, opts: opts });
      root.appendChild(card);
    },

    // Search pages: the cards already carry scores, so rank them. The biggest gaps between asking and estimate first.
    deals: function (items, opts) {
      var existing = document.getElementById('lowball-panel');
      if (existing && existing.getAttribute('data-state') !== 'waiting' && existing.getAttribute('data-state') !== 'deals') return;
      var root = mountHost(); host.setAttribute('data-state', 'deals'); host.classList.remove('lb-waiting');
      var card = h('div', 'card medium'); header(card, 'Lowball', 'This search', opts);
      var body = h('div', 'body');
      body.appendChild(t('div', 'label', 'Most negotiable on this page'));
      var nb = items.filter(function (it) { return it.building; }).length, nh = items.length - nb;
      body.appendChild(t('div', 'sub', (nh ? nh + ' listing' + (nh === 1 ? '' : 's') : '') + (nh && nb ? ' and ' : '') + (nb ? nb + ' building floor plan' + (nb === 1 ? '' : 's') : '') + ' scored · ranked by what you could ask off, against ' + (opts.roughIndex ? 'a ZIP rent index, rough' : 'what similar listings nearby ask')));
      var tb = h('table', 'units'); var tr0 = h('tr'); ['Listing', 'Asking', 'Offer', 'Per year'].forEach(function (s, i) { tr0.appendChild(t('th', i ? 'n' : null, s)); }); tb.appendChild(tr0);
      items.slice(0, 8).forEach(function (it) {
        var tr = h('tr'); tr.style.cursor = 'pointer'; tr.title = it.newTab ? 'Opens in a new tab (this listing is not in the list on this page)' : 'Open this listing here. Ctrl-click for a new tab';
        var td = t('td', null, (it.refined ? '· ' : '') + it.label + (it.newTab ? ' \u2197' : '')); tr.appendChild(td); tr.appendChild(t('td', 'n', money(it.asking))); tr.appendChild(t('td', 'n open', money(it.offer)));
        // Same basis as the panel: what it saves if it lands where we expect, not if the opening offer is accepted
        // outright. Two surfaces quoting two annual figures for one listing is worse than either figure alone.
        var land = it.settle != null ? it.settle : it.offer;
        var yrAmt = it.asking && land ? Math.round((it.asking - land) * 12) : 0;
        var ov = t('td', 'n', yrAmt > 0 ? money(yrAmt) : '\u2014'); ov.style.color = yrAmt <= 0 ? '#98A2B3' : '#067647'; ov.style.fontWeight = '700';
        ov.title = yrAmt > 0 ? money(it.asking - land) + '/mo below asking over a 12-month lease, if it lands near ' + money(land) + (it.beyond ? '. Priced beyond every comparable we hold, so the estimate is a floor, not a target' : '') : 'Asking is at or below what similar listings nearby ask';
        tr.appendChild(ov);
        var flash = function () { td.textContent = 'Opened in a new tab \u2197'; setTimeout(function () { td.textContent = (it.refined ? '· ' : '') + it.label + ' \u2197'; }, 1800); };
        tr.addEventListener('click', function (ev) { if (it.open) it.open(ev, flash); else if (it.href) window.open(it.href, '_blank', 'noopener'); });   // never navigate the search page: that resets the map to the listing's city
        tr.addEventListener('auxclick', function (ev) { if (ev.button === 1 && it.open) { ev.preventDefault(); it.open(ev, flash); } });
        tb.appendChild(tr);
      });
      tb.style.marginTop = '10px'; body.appendChild(tb);
      body.appendChild(t('div', 'sub', 'From the search cards, so opening a listing can move its number. Rows marked · are refined from the full listing.'));
      card.appendChild(body);
      footer(card, 'Estimates are not advice or a guarantee. Not affiliated with Zillow.', { api: opts.api, pageUrl: opts.pageUrl, listing: { address: 'search' }, result: {}, opts: opts });
      root.appendChild(card);
    },

    waiting: function (opts) {
      var existing = document.getElementById('lowball-panel');
      if (existing && existing.getAttribute('data-state') === 'waiting') return;
      var root = mountHost(); host.setAttribute('data-state', 'waiting'); host.classList.add('lb-waiting');
      var card = h('div', 'card waiting');
      var head = h('div', 'head'); head.appendChild(h('div', 'mark', ICON.mark)); head.appendChild(t('span', 'wordmark', 'Lowball'));
      head.appendChild(t('span', 'waitmsg', 'Open a listing to see an offer'));
      var close = h('button', 'ib', ICON.x); close.title = 'Hide'; close.addEventListener('click', function () { opts.onClose && opts.onClose(); host.remove(); });
      head.appendChild(close); card.appendChild(head); root.appendChild(card);
    },

    moveIntoTopDialog: function () {
      var p = document.getElementById('lowball-panel'); if (!p) return;
      var dlgs = document.querySelectorAll('dialog:modal'); var top = dlgs.length ? dlgs[dlgs.length - 1] : null;
      if (top && !top.contains(p)) top.appendChild(p);
    }
  };
  window.LowballUI = UI;
})();
